# README #

This repository purpose is for Kleen API/CMS

### How do I get set up? ###

* Setting Git Environment for Bitbucket ( http://guganeshan.com/blog/setting-up-git-and-tortoisegit-with-bitbucket-step-by-step.html )
* Intall TortoiseGIT for Windows
* Git init on any local folder and do Git Clone ( https://bitbucket.org/danis-teknologi-maju/api-cms#clone )

### Contribution guidelines ###

* Switch / Checkout to your branch (Ex: "Adam" Repo branched from "Development"
* Code on your local, commit on every chances.
* Push to your remote branch repository (Ex: "Adam") when completes any task.
* Create a Pull Request ( https://bitbucket.org/danis-teknologi-maju/api-cms/pull-requests/ ) from your Branch (Ex: "Adam") to "Development" Branch. NOTE: don't make another push until your Branch is Merged and Admin let you pull the latest merged Repo.
* Pull the latest source from your remote branch repo (Ex: "Adam")

### Who do I talk to? ###

* Repo owner or admin ( @delpierrol / @danz_oye )