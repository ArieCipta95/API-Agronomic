<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['server_key'] = "VT-server-z2faO7sd2L4AZ1IaJ6aFl4hk";
$config['production'] = false;