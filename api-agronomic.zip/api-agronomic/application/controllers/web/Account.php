<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$return = false;
		$this->load->library('web/user_web');
		if($action = $this->input->get_post('action',true)){
			switch($action){
				case 'confirm':
					$return = $this->user_web->confirmEmail();
					break;
				case 'forgotpassword':
					$return = $this->user_web->forgotPassword();
					break;
				default:break;	
			}
		}
		
		if($return){
			redirect('/');	
		}
	}
	
	//public function test(){
//		$emailConfig = array(
//		   'protocol' => 'smtp',
//			'smtp_host' => 'ssl://smtp.googlemail.com',
//			'smtp_port' => 465,
//			'smtp_user' => 'development.googaga@gmail.com',
//			'smtp_pass' => 'Gokleen123!@#456',
//			'mailtype'  => 'html', 
//			'charset'   => 'utf-8',
//			'starttls'  => true,
//		);
//		
//		$from = array('email' => 'development.googaga@gmail.com', 'name' => 'GOOGAGA');
//		//$to = array($email['to']);
//		//$subject = $email['subject'];
//		 
//		$message = 'ini test message email';//$email['message'];
//		
//		// Load CodeIgniter Email library
//		$this->load->library('email', $emailConfig);
//		$this->email->set_newline("
//");
//		$this->email->from($from['email'], $from['name']);
//		$this->email->to(array('errol.widhavian@gmail.com'));
//		$this->email->subject('tst');
//		$this->email->message($message);
//		if (!$this->email->send()) {
//			// Raise error message
//			echo '<pre>';print_r($this->email->print_debugger());echo '</pre>';
//		}
//		else {
//			echo 'email sent';
//		}	
//	}
	
}
