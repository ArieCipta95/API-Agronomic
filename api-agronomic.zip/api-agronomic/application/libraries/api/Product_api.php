<?php defined('BASEPATH') or exit('No direct script access allowed');
/**
 * UnZip Class
 *
 * This class is based on a library I found at PHPClasses:
 * http://phpclasses.org/package/2495-PHP-Pack-and-unpack-files-packed-in-ZIP-archives.html
 *
 * The original library is a little rough around the edges so I
 * refactored it and added several additional methods -- Phil Sturgeon
 *
 * This class requires extension ZLib Enabled.
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Encryption
 * @author		Alexandre Tedeschi
 * @author		Phil Sturgeon
 * @author		Don Myers
 * @link		http://bitbucket.org/philsturgeon/codeigniter-unzip
 * @license     
 * @version     1.0.0
 */
class Product_api {
	private $CI;    
	var $limit = 10; 
	
	function __construct()
	{
		$this->CI =& get_instance();
		$this->CI->load->helper('string');
		$this->CI->load->model('api/product/Select_product', '', TRUE);
		$this->CI->load->model('api/product/Insert_product', '', TRUE);
		$this->CI->load->model('api/product/Update_product', '', TRUE);
		//$this->CI->load->model('api/media/Select_media', '', TRUE);
	}
	
	public function getProduct(){
		$return['status'] = 1;
	    $return['data']['product'] = array();
		if(!empty($this->CI->input->post('product_id',TRUE)))
			$this->CI->load->model('api/product/Select_product', '', TRUE);
		$offset = (int)$this->CI->input->post('page',TRUE);
		if(!$offset) $offset = 1;
		if($products = $this->CI->Select_product->get_where($offset)){
			
			$totalProduct = $this->CI->Select_product->get_count();
			$totalPage = ceil($totalProduct/$this->limit);
			if($offset<$totalPage)
				$return['data']['next'] = $offset+1;
			$e = 0;
			foreach($products as $product){
				$return['data']['product'][$e] = $this->productDetail($product['fproductid'],$product);				
				$e++;
			}
		}else				
			$return['data']['product'] = null;
		return $return;	
	}
	
	public function productBySearch(){
		$return['status'] = 1;
	    $return['data']['product'] = array();
		$offset = (int)$this->CI->input->post('page',TRUE);
		if(!$offset) $offset = 1;
		if($products = $this->CI->Select_product->get_search($offset)){
			$totalProduct = $this->CI->Select_product->get_search_count();
			$totalPage = ceil($totalProduct/$this->limit);
			if($offset<$totalPage)
				$return['data']['next'] = $offset+1;
			$e = 0;
			foreach($products as $product){
				$return['data']['product'][$e] = $this->productDetail($product['fproductid'],$product);				
				$e++;
			}	
		}else				
			$return['data']['product'] = null;
		return $return;	
	}
	
	public function productByFeatured(){
		if(!empty($this->CI->input->post('user_id',TRUE)))
			$this->CI->load->model('api/user/Select_user', '', TRUE);
		$return['status'] = 1;
		$return['data']['product'] = array();
		$offset = (int)$this->CI->input->post('page',TRUE);
		if(!$offset) $offset = 1;
		if($products = $this->CI->Select_product->get($offset,'featured')){
			$totalProduct = $this->CI->Select_product->get_count('featured');
			$totalPage = ceil($totalProduct/$this->limit);
			if($offset<$totalPage)
				$return['data']['next'] = $offset+1;
			
			$e = 0;
			foreach($products as $product){
				$return['data']['product'][$e] = $this->productDetail($product['fproductid'],$product);		
				
				$e++;
			}
		}else
			$return['data']['product'] = null;
		return $return;	
	}
	
	public function productDetail($id=0,$product=array()){
		$return = array();
		if(empty($product)){
			$where['fproductid'] = $id;
			$product = $this->CI->Select_product->get_where($where);
		}
		if(!empty($product)){
			$return = array(
				'id' => $product['fproductid'],
				'name' => $product['fproductname'],
				'description' => $product['fproductdesc'],
				'product_type' => 'seasonal',
				'open_hour' => $product['fproductopen'],
				'close_hour' => $product['fproductclose'],
				'start_date' => $product['fproductstartdate'],
				'end_date' => $product['fproductenddate'],
				'rating' => $product['fproductrating'],
				'start_from_price' => $product['fproductprice'],
				'start_from_special_price' => $product['fproductspecialprice'],
				'currency' => 'IDR',
				'due_day' => $product['fproductexpireddate'],
				'my_wishlist' => 'false',
				'category' => array(
					'id' => $product['fcategoryid'],
					'category_name' => $product['fcategoryname'],
					'icon' => $product['fcategoryicon'],
					'cover' => $product['fcategorycover'],
					'bgcolor' => $product['fcategorybgcolor'],
					'font_color' => $product['fcategoryfontcolor']
				),
				'merchant' => array(
					'id' => $product['fmerchantid'],
					'merchant_name' => $product['fmerchantname'],
					'description' => $product['fmerchantdesc'],
					'phone' => $product['fmerchantphone'],
					'email' => $product['fmerchantemail']
				),
				'created_date' => $product['fproductcreateddate'],
				'modified_date' => $product['fproductmodifieddate'],
				'location' => array(
					'address' => $product['fproductaddress'],
					'kecamatan' => $product['fproductkecamatan'],
					'postal_code' => $product['fproductpostal'],
					'country' => 'Indonesia',
					'province' => array(
						'id' => $product['fprovinceid'],
						'name' => $product['fprovincename']
					),
					'city' => array(
						'id' => $product['fcityid'],
						'name' => $product['fcityname']
					),
					'coordinate' => array(
						'lat' => $product['fproductlat'],
						'lon' => $product['fproductlon']
					),
					'distance' => round($product['distance']),
				),					
				'images' => null,
				'is_featured' => false,
				'is_promotion' => false,
			);
			
			$return['merchant']['is_showing'] = ($product['fcategoryshowmerchant']) ? 'true' : false;
			
			switch($product['fproducttype']){
				case 2: 
					$return['product_type'] = 'routine';	
					break;
				default:break;
			}
			
			$return['stock'] = ($product['fproducttotalstock']) ? 'in stock' : 'out of stock';
			
			if(!empty($this->CI->input->post('user_id',TRUE))){				
				$meta['tusers.fuserid'] = 	$this->CI->input->post('user_id',TRUE);
				$meta['fmetakey'] = 'wishlist';
				$meta['fmetavalue'] = $product['fproductid'];
				if($wishlist = $this->CI->Select_user->get_meta_where($meta)){
					$return['my_wishlist'] = true;	
				}
				$rev['treview.fuserid'] = $meta['tusers.fuserid'];
				$rev['treview.fproductid'] = $product['fproductid'];
				if($review = $this->CI->Select_product->get_review_where($rev,'single')){
					$return['my rating'] = $this->getDetailReview($review);
				}
			}
			
			$img['fproductid'] = $product['fproductid'];
			if($images = $this->CI->Select_media->get_product($img,false)){
				foreach($images as $image){
					$return['images'][] = base_url($image['fmediapath']);
				}
			}
			
			if($product['fproductfeatured']) $return['is_featured'] = true;
			if($product['fproductpromoted']) $return['is_promotion'] = true;
		}
		return $return;	
	}
	
	public function productSchedule(){
		$return['status'] = 1;
		$return['data']['available_schedule'] = array();
		$meta['tproductmeta.fproductid'] = $this->CI->input->post('product_id',TRUE);
		$meta['fmetakey'] = 'schedule';
		if($schedules = $this->CI->Select_product->get_meta_where($meta,false)){
			$return['data']['available_schedule'] = array();
			$s = 0;
			foreach($schedules as $schedule){
				if(strpos($schedule['fmetavalue'],',')!==FALSE){
					$spl = explode(",",$schedule['fmetavalue']);
					$start_date = $spl[0];
					$end_date = $spl[1];	
					
					if($end_date>time()){
						$return['data']['available_schedule'][$s] = array(
							'id' => $schedule['fproductmetaid'],
							'start_date' => $start_date,
							'end_date' => $end_date
						);
						$s++;
					}
				}
			}
		}else
			$return['data']['available_schedule'] = null;
		return $return;	
	}
	
	public function productTicket($action='get'){	
		$return = array();
		switch($action){
			case 'validate':
				$return = $this->validateTicket();
				break;
			default:
				$return = $this->getTicket();
				break;	
		}
		return $return;	
	}
	
	public function getTicket(){			
		$return['status'] = 1;
		$return['data']['tickets'] = array();
		if($tickets = $this->CI->Select_product->get_tickets()){
			$s = 0;
			foreach($tickets as $ticket){
				$cl['fticketid'] = $ticket['fticketid'];
				$cl['fcartsubmitted'] = 0;
				$claimed_stock = $this->CI->Select_product->get_claimed($cl,true);
				$current_stock = $ticket['fticketstock']-$claimed_stock;
				if($current_stock >= 1){
					$return['data']['tickets'][$s] = array(
						'id' => $ticket['fticketid'],
						'ticket_type' => $ticket['fticketname'],
						'price' => $ticket['fticketprice'],
						'special_price' => $ticket['fticketsaleprice'],
						'currency' => $ticket['fticketcurrency'],
						'stock' => $current_stock,
					);
				}
				$s++;	
			}
		}else
			$return['data']['tickets'] = null;
		
		return $return;
	}
	
	private function validateTicket(){
		$this->CI->load->model('api/order/Select_order', '', TRUE);
		$this->CI->load->model('api/order/Update_order', '', TRUE);
		$this->CI->load->model('api/user/Select_user', '', TRUE);
		$return['status'] = 1;
		$return['data']['status']['success'] = false;
		$where['fuserid'] = $this->CI->input->post('user_id',TRUE);
		if($user = $this->CI->Select_user->get_where($where)){
			if($participant_id = $this->CI->input->post('participant_id',TRUE)){
				$where['fcartid'] = $participant_id;
				$where['fticketstatus'] = 2;
				if($ticket = $this->CI->Select_order->get_cart_where($where)){	
					$ca['fticketstatus'] = 3;
					$this->CI->Update_order->updateCart($ca,$where);	
	
					$no['forderid'] = $ticket['forderid'];
					$no['fticketstatus'] = 2;
					if(!$noticket = $this->CI->Select_order->get_cart_where($no)){
						if($product = $this->CI->Select_order->get_ticket_product_where(array('fticketid'=>$ticket['fticketid']))){
							$email = array(
								'to' => $user['fuseremail'],
								'subject' => '[Googaga] Activity Review & Feedback for Order #'.$ticket['forderid'],
								'username' => ucwords($user['fuserfullname']),
							);
							
							$email['product'] = array(
								'id' => $product['fproductid'],
								'image' => backend_assets('img/').'no-image.png',
								'name' => $product['fproductname']
							);
							$img['fproductid'] = $product['fproductid'];
							if($images = $this->CI->Select_media->get_product($img,false)){
								$image = base_url($images[0]['fmediapath']);
								if(!empty($image)) 	$email['product']['image'] = $image;
							}
							$email['message'] = $this->CI->load->view('email/feedback',$email,true);
							
							if($this->CI->user_api->userSendMail($email)){
								$act['factivitystatus'] = 2;
								$this->CI->Update_order->updateActivity($act,array('forderid' => $no['forderid']));	
							}
						}
					}				
					
					$return['data']['status']['success'] = true;
				}
			}
		}
		return $return;	
	}
	
	public function productReview($action='read'){
		$return = array();
		switch($action){
			case 'submit':
				$return = $this->submitReview();
				break;
			case 'edit';
				$return = $this->updateReview();
				break;
			case 'delete';
				$return = $this->deleteReview();
				break;
			default:
				$return = $this->getReview();
				break;
					
		}
		return $return;
	}
	
	private function getReview(){
		$return['status'] = 1;
		$return['data']['review'] = array();
		$offset = (int)$this->CI->input->post('page',TRUE);
		if(!$offset) $offset = 1;
		if($reviews = $this->CI->Select_product->get_review($offset)){
			$totalReviews = $this->CI->Select_product->get_review(FALSE,TRUE);
			$totalPage = ceil($totalReviews/$this->limit);
			if($offset<$totalPage)
				$return['data']['next'] = $offset+1;
			$e = 0;
			foreach($reviews as $review){
				$return['data']['review'][$e] = $this->getDetailReview($review);
				$e++;
			}
		}else{
			$return['data']['review'] = null;	
		}
		return $return;	
	}
	
	private function getDetailReview($review){
		$return = array();
		if(!empty($review)){
			$return = array(
				'id' => $review['freviewid'],
				'text' => $review['freviewtext'],
				'created_by' => array(
					'user id' => $review['fuserid'],
					'fullname' => $review['fuserfullname'],
					'birthdate' => $review['fuserbirthdate'],
					'email' => $review['fuseremail'],
					'picture' => $review['fuserprofpic'],
					'user_type' => 'adult',
					'gender' => null,
					'parent_id' => 0,
					'is_verified' => false
				),
				'created date' => $review['freviewdate'],
				'rating' => $review['freviewrating']
			);
			if(!empty($review['fuserparentid'])){
				$return['created_by']['user_type'] = 'child';
				$return['created_by']['parent_id'] = $review['fuserparentid'];
			}
			if(strpos($review['fuserprofpic'],'/assets/media/')!==FALSE)
				$return['created_by']['picture'] = base_url($review['fuserprofpic']);
			if($review['fuserstatus']==1) $return['created_by']['is_verified'] = true;	
		}
		return $return;	
	}
	
	private function submitReview(){
		$return['status'] = 1;
		
		$insert['fuserid'] = $activity['fuserid'] = $where['treview.fuserid'] = $this->CI->input->post('user_id',TRUE);
		$insert['fproductid'] = $activity['fproductid'] = $where['treview.fproductid'] = $this->CI->input->post('product_id',TRUE);
		$insert['freviewrating'] = $this->CI->input->post('rating', TRUE);
		$insert['freviewtext'] = $this->CI->input->post('review', TRUE);
		
		if($this->CI->Select_product->get_activity($activity,true)){
			if(empty($this->CI->Select_product->get_review_where($where,true))){
				if($rev['freviewid'] = $this->CI->Insert_product->addReview($insert)){
					$this->updateRating($insert['fproductid']);
					$return['data']['review'] = array();	
					if($review = $this->CI->Select_product->get_review_where($rev,'single')){
						$return['data']['review'] = $this->getDetailReview($review);
					}
				}
			}else{
				$return['status'] = 2;
				$return['message'] = 'You already review this product.';
				$return['error'] = 'review exist for current user.';
				$return['code'] = '1006';	
			}
		}else{
			$return['status'] = 2;
			$return['message'] = 'You cannot review this activity until you ordered and redeemed one or more ticket\'s activity';
			$return['error'] = 'no activity for current user.';
			$return['code'] = '1005';	
		}
		
		return $return;
	}
	
	private function updateReview(){
		$return['status'] = 1;
		
		$where['treview.fuserid'] = $this->CI->input->post('user_id',TRUE);
		$where['freviewid'] = $this->CI->input->post('review_id',TRUE);
		$update['freviewrating'] = $this->CI->input->post('rating', TRUE);
		$update['freviewtext'] = $this->CI->input->post('review', TRUE);
		
		if($review = $this->CI->Select_product->get_review_where($where,'single')){
			if($this->CI->Update_product->updateReview($update,array('freviewid'=>$review['freviewid']))){
				$this->updateRating($review['fproductid']);
				$return['data']['review'] = array();	
				if($review = $this->CI->Select_product->get_review_where(array('freviewid'=>$review['freviewid']),'single')){
					$return['data']['review'] = $this->getDetailReview($review);
				}
			}
		}
		
		return $return;
	}
	
	private function deleteReview(){
		$return['status'] = 1;
		$return['data']['status']['success'] = false;
		
		$update['freviewstatus'] = 2;
		$where['freviewid'] = $this->CI->input->post('review_id',TRUE);
		
		if($this->CI->Update_product->updateReview($update,$where)){
			$return['data']['status']['success'] = true;
		}
		
		return $return;
	}
	
	private function updateRating($productID=0){
		if(!empty($productID)){
			$where['treview.fproductid'] = $updated['fproductid'] = $productID;
			if($reviews = $this->CI->Select_product->get_review_where($where,false)){
				$rating = 0;
				foreach($reviews as $review){
					$rating = $rating + $review['freviewrating'];	
				}
				$update['fproductrating'] = round($rating / count($reviews));
				$this->CI->Update_product->updateProduct($update,$updated);
			}
		}
	}
}

/* End of file Unzip.php */
/* Location: ./system/libraries/Unzip.php */