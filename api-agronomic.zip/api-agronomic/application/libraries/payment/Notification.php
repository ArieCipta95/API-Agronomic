<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Notification {
	private $CI;   
	
	function __construct()
	{
		$this->CI =& get_instance();
		$this->CI->load->helper('string');
		$this->CI->load->model('api/order/Select_order', '', TRUE);
		$this->CI->load->model('api/order/Insert_order', '', TRUE);
		$this->CI->load->model('api/order/Update_order', '', TRUE);
		$this->CI->load->model('api/media/Select_media', '', TRUE);

		$this->CI->load->model('backend/option/Select_option', '', TRUE);
		$this->CI->load->library('api/user_api');
		$this->CI->load->helper('string');
	}
	
	public function process_order($or,$ord){
		$return = false;
		if($order = $this->CI->Select_order->get_order_contact_where($ord)){			
			if(!empty($or)){
				$this->CI->Update_order->updateOrder($or,$ord);	
				if(!empty($or['forderprocessed'])){
					$email = array(
						'to' => $order['fuseremail'],
						'file' => 'mainemail',
						'subject' => '[GOKLEEN] Confirm for Order #'.$order['forderid'],
						'status_code' => $or['forderprocessed'],
						'status' => 'Awaiting Payment',
						'order_id' => $order['forderid'],
						'customer_id' => $order['fuserid'],
						'customer' => ucwords($order['fuserfirstname'].' '.$order['fuserlastname']),
						'customer_email' => $order['fuseremail'],
						'customer_phone' => $order['fuserphone'],
						'attachment' => false,
						'email_status' => 1,
						'payment_prefix' => 'defaut',
					);
					
					$cl['torder.forderid'] = $order['forderid'];
				}
				if(!empty($email)){								
					$email['message'] = $this->CI->load->view('email/'.$email['file'],$email,true);
					if($order['forderemailsent']!=6){
						$ca = 1;
						if($claims = $this->CI->Select_order->get_order_cart_where($cl,false)){
							/*print_r($email);*/
							$claimedservice = 0;
							$option['tclaimedservice.fcartid'] = $claims['fcartid'];

							if($claimeds = $this->CI->Select_order->get_claimed_service_where(($option))){
								$services = unserialize($claimeds['fclaimedservice']);
								if(!empty($services)){
									foreach($services as $serv){
										$email['serviceid'] = $serv->service->id;
									}
								}
							}	
							
							if($se['tsubservice.fserviceid'] = $email['serviceid']){
								$servicedetail = $this->CI->Select_order->get_service_where($se);
								print_r($servicedetail);
								if(is_array($servicedetail))
								foreach ($servicedetail as $servicedtl) {
									$email112 = isset($servicedtl['fservicename']);	
								}
							}
						}
						
						if($this->CI->user_api->userSendMail($email)){
							$em['forderemailsent'] = $email['email_status'];
							$this->CI->Update_order->updateOrder($em,$ord);	
						}
					}
				}
				
				/*if(!empty($ca)){
					$car['forderid'] = $order['forderid'];
					$this->CI->Update_order->updateOrder($ca,$car);	
				}*/
				
			}
		return $return;	
		}
	}
}
