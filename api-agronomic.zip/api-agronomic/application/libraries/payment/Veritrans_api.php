<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Veritrans_api {
	private $CI;
	/**
   	* Your merchant's server key
   	* @static
   	*/
	public static $serverKey = '';
	
	/**
   	* true for production
   	* false for sandbox mode
   	* @static
   	*/
	public static $isProduction = false;
	
	/**
   	* true for production
   	* false for sandbox mode
   	* @static
   	*/
	public static $isSanitized = false;
	
	/**
   	* true for production
   	* false for sandbox mode
   	* @static
   	*/
	public static $is3ds = false;

   	/**
   	* Default options for every request
   	* @static
   	*/
  	public static $curlOptions = array();	

  	const SANDBOX_BASE_URL = 'https://app.sandbox.midtrans.com/snap/v1/';
  	const PRODUCTION_BASE_URL = 'https://app.midtrans.com/snap/v1/';

    public function __construct()
    {
		$this->CI =& get_instance();
		$this->CI->config->load('veritrans_api');
        Veritrans_api::$serverKey =  $this->CI->config->item('server_key');
        Veritrans_api::$isProduction = $this->CI->config->item('production');
        Veritrans_api::$isSanitized = $this->CI->config->item('sanitize');
        Veritrans_api::$is3ds = true;
    }

    /**
    * @return string Veritrans API URL, depends on $isProduction
    */
  	public static function getBaseUrl()
  	{
    	return Veritrans_api::$isProduction ?
        	Veritrans_api::PRODUCTION_BASE_URL : Veritrans_api::SANDBOX_BASE_URL;
  	}
	
	
	public static function getSnapToken($params)
	{
		$payloads = array(
			'credit_card' => array(
				// 'enabled_payments' => array('credit_card'),
				'secure' => Veritrans_api::$is3ds
			)
		);
	
		if (array_key_exists('item_details', $params)) {
			$gross_amount = 0;
			foreach ($params['item_details'] as $item) {
				$gross_amount += $item['quantity'] * $item['price'];
			}
			$params['transaction_details']['gross_amount'] = $gross_amount;
		}
	
		if (Veritrans_api::$isSanitized) {
			self::jsonRequest($params);
		}
	
		$params = array_replace_recursive($payloads, $params);
		
		$result = self::snap_charge($params);
	
		return $result->token_id;
	  }

	/**
	 * Send GET request
	 * @param string  $url
	 * @param string  $server_key
	 * @param mixed[] $data_hash
	 */
	public static function get($url, $server_key, $data_hash)
	{
	  return self::remoteCall($url, $server_key, $data_hash, false);
	}

	/**
	 * Send POST request
	 * @param string  $url
	 * @param string  $server_key
	 * @param mixed[] $data_hash
	 */
	public static function post($url, $server_key, $data_hash)
	{
	    return self::remoteCall($url, $server_key, $data_hash, true);
	}

  	/**
	 * Actually send request to API server
	 * @param string  $url
	 * @param string  $server_key
	 * @param mixed[] $data_hash
	 * @param bool    $post
	 */
    public static function remoteCall($url, $server_key, $data_hash, $post = true)
    {	
	    $ch = curl_init();

	    $curl_options = array(
	      CURLOPT_URL => $url,
	      CURLOPT_HTTPHEADER => array(
	        'Content-Type: application/json',
	        'Accept: application/json',
	        'Authorization: Basic ' . base64_encode($server_key . ':')
	      ),
	      CURLOPT_RETURNTRANSFER => 1,
	      CURLOPT_CAINFO => dirname(__FILE__) . "/veritrans/cacert.pem"
	    );

	    // merging with Veritrans_Config::$curlOptions
	    if (count(Veritrans_api::$curlOptions)) {
	      // We need to combine headers manually, because it's array and it will no be merged
	      if (Veritrans_api::$curlOptions[CURLOPT_HTTPHEADER]) {
	        $mergedHeders = array_merge($curl_options[CURLOPT_HTTPHEADER], Veritrans_api::$curlOptions[CURLOPT_HTTPHEADER]);
	        $headerOptions = array( CURLOPT_HTTPHEADER => $mergedHeders );
	      } else {
	        $mergedHeders = array();
	      }

	      $curl_options = array_replace_recursive($curl_options, Veritrans_api::$curlOptions, $headerOptions);
	    }

	    if ($post) {
	      $curl_options[CURLOPT_POST] = 1;

	      if ($data_hash) {
	        $body = json_encode($data_hash);
	        $curl_options[CURLOPT_POSTFIELDS] = $body;
	      } else {
	        $curl_options[CURLOPT_POSTFIELDS] = '';
	      }
	    }

	    curl_setopt_array($ch, $curl_options);

	    $result = curl_exec($ch);
		$info = curl_getinfo($ch);
	   //  curl_close($ch);
	   
	    if ($result === FALSE) {
	      throw new Exception('CURL Error: ' . curl_error($ch), curl_errno($ch));
	    }
	    else {
	      $result_array = json_decode($result);
		 if ($info['http_code'] != 200) {
			$message = 'Veritrans Error (' . $info['http_code'] . '): '
				. implode(',', $result_array->error_messages);
			throw new Exception($message, $info['http_code']);
	
		  }
		  else {
			return $result_array;
		  }
	    }
    }

    public static function vtweb_charge($payloads)
    {	

    	$result = Veritrans_api::post(
        Veritrans_api::getBaseUrl() . '/charge',
        Veritrans_api::$serverKey,
        $payloads);

        return $result->redirect_url;


    	//$url = Veritrans_api::getBaseUrl();
    	//return Veritrans_api::$serverKey.Veritrans_api::getBaseUrl() . '/charge' ;
    }

    public static function vtdirect_charge($payloads)
    {	

    	$result = Veritrans_api::post(
        Veritrans_api::getBaseUrl() . '/charge',
        Veritrans_api::$serverKey,
        $payloads);

        return $result;


    	//$url = Veritrans_api::getBaseUrl();
    	//return Veritrans_api::$serverKey.Veritrans_api::getBaseUrl() . '/charge' ;
    }

    public static function snap_charge($payloads)
    {	

    	$result = Veritrans_api::post(
        Veritrans_api::getBaseUrl() . '/charge',
        Veritrans_api::$serverKey,
        $payloads);

        return $result->token_id;


    	//$url = Veritrans_api::getBaseUrl();
    	//return Veritrans_api::$serverKey.Veritrans_api::getBaseUrl() . '/charge' ;
    }
	
    /**
   	* Retrieve transaction status
   	* @param string $id Order ID or transaction ID
    * @return mixed[]
    */
	public static function status($id)
 	{
    	return Veritrans_api::get(
        	Veritrans_api::getBaseUrl() . '/' . $id . '/status',
        	Veritrans_api::$serverKey,
        	false);
  	}

  	/**
   	* Appove challenge transaction
   	* @param string $id Order ID or transaction ID
   	* @return string
   	*/
  	public static function approve($id)
  	{
    	return Veritrans_api::post(
        	Veritrans_api::getBaseUrl() . '/' . $id . '/approve',
        	Veritrans_api::$serverKey,
        	false)->status_code;
  	}

  	/**
   	* Cancel transaction before it's setteled
   	* @param string $id Order ID or transaction ID
   	* @return string
   	*/
  	public static function cancel($id)
  	{
    	return Veritrans_api::post(
        	Veritrans_api::getBaseUrl() . '/' . $id . '/cancel',
        	Veritrans_api::$serverKey,
        	false)->status_code;
  	}

   /**
    * Expire transaction before it's setteled
    * @param string $id Order ID or transaction ID
    * @return mixed[]
    */
  	public static function expire($id)
  	{
    	return Veritrans_api::post(
        	Veritrans_api::getBaseUrl() . '/' . $id . '/expire',
        	Veritrans_api::$serverKey,
        	false);
  	}/**
   * Validates and modify data
   * @param mixed[] $json
   */
  public static function jsonRequest(&$json)
  {
    $keys = array('item_details', 'customer_details');
    foreach ($keys as $key) {
      if (!array_key_exists($key, $json)) continue;

      $camel = static::upperCamelize($key);
      $function = "field$camel";
      static::$function($json[$key]);
    }
  }

  private static function fieldItemDetails(&$items)
  {
    foreach ($items as &$item) {
      $id = new self;
      $item['id'] = $id
          ->maxLength(50)
          ->apply($item['id']);
      $name = new self;
      $item['name'] = $name
          ->maxLength(50)
          ->apply($item['name']);
    }
  }

  private static function fieldCustomerDetails(&$field)
  {
    $first_name = new self;
    $field['first_name'] = $first_name
        ->maxLength(20)
        ->apply($field['first_name']);
    if (array_key_exists('last_name', $field)) {
      $last_name = new self;
      $field['last_name'] = $last_name
          ->maxLength(20)
          ->apply($field['last_name']);
    }
    $email = new self;
    $field['email'] = $email
        ->maxLength(45)
        ->apply($field['email']);

    static::fieldPhone($field['phone']);

    $keys = array('billing_address', 'shipping_address');
    foreach ($keys as $key) {
      if (!array_key_exists($key, $field)) continue;

      $camel = static::upperCamelize($key);
      $function = "field$camel";
      static::$function($field[$key]);
    }
  }

  private static function fieldBillingAddress(&$field)
  {
    $fields = array(
        'first_name'   => 20,
        'last_name'    => 20,
        'address'      => 200,
        'city'         => 20,
        'country_code' => 10
      );

    foreach ($fields as $key => $value) {
      if (array_key_exists($key, $field)) {
        $self = new self;
        $field[$key] = $self
            ->maxLength($value)
            ->apply($field[$key]);
      }
    }

    if (array_key_exists('postal_code', $field)) {
      $postal_code = new self;
      $field['postal_code'] = $postal_code
          ->whitelist('A-Za-z0-9\\- ')
          ->maxLength(10)
          ->apply($field['postal_code']);
    }
    if (array_key_exists('phone', $field)) {
      static::fieldPhone($field['phone']);
    }
  }

  private static function fieldShippingAddress(&$field)
  {
    static::fieldBillingAddress($field);
  }

  private static function fieldPhone(&$field)
  {
    $plus = substr($field, 0, 1) === '+' ? true : false;
    $self = new self;
    $field = $self
        ->whitelist('\\d\\-\\(\\) ')
        ->maxLength(19)
        ->apply($field);

    if ($plus) $field = '+' . $field;
    $self = new self;
    $field = $self
        ->maxLength(19)
        ->apply($field);
  }

  private function maxLength($length)
  {
    $this->filters[] = function($input) use($length) {
      return substr($input, 0, $length);
    };
    return $this;
  }

  private function whitelist($regex)
  {
    $this->filters[] = function($input) use($regex) {
      return preg_replace("/[^$regex]/", '', $input);
    };
    return $this;
  }

  private function apply($input)
  {
    foreach ($this->filters as $filter) {
      $input = call_user_func($filter, $input);
    }
    return $input;
  }

  private static function upperCamelize($string)
  {
    return str_replace(' ', '',
        ucwords(str_replace('_', ' ', $string)));
  }

}
