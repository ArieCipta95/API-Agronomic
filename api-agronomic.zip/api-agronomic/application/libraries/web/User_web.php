<?php defined('BASEPATH') or exit('No direct script access allowed');
/**
 * UnZip Class
 *
 * This class is based on a library I found at PHPClasses:
 * http://phpclasses.org/package/2495-PHP-Pack-and-unpack-files-packed-in-ZIP-archives.html
 *
 * The original library is a little rough around the edges so I
 * refactored it and added several additional methods -- Phil Sturgeon
 *
 * This class requires extension ZLib Enabled.
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Encryption
 * @author		Alexandre Tedeschi
 * @author		Phil Sturgeon
 * @author		Don Myers
 * @link		http://bitbucket.org/philsturgeon/codeigniter-unzip
 * @license     
 * @version     1.0.0
 */
class User_web {
	private $CI;    
	
	function __construct()
	{
		$this->CI =& get_instance();
		$this->CI->load->helper('string');
		$this->CI->load->model('web/user/Select_user', '', TRUE);
		$this->CI->load->model('web/user/Insert_user', '', TRUE);
		$this->CI->load->model('web/user/Update_user', '', TRUE);
		$this->CI->load->library('api/user_api');
	}
	
	public function confirmEmail(){
		$where['fusercode'] = $this->CI->input->get('key',TRUE);
		$where['fuseremail'] = rawurldecode($this->CI->input->get('auth',TRUE));
		if($user = $this->CI->Select_user->get_where($where)){
			$data['url'] = site_url();
			$email['to'] = $user['fuseremail'];
			$email['subject'] = 'Welcome to Go-Kleen!';
			$email['message'] = $this->CI->load->view('email/welcome',$data,true);
			if($this->CI->user_api->userSendMail($email)){
				$update['fusercode'] = '';
				$update['fuserstatus'] = 1;
				$this->CI->Update_user->updateUser($update,$where);
				return true;
			}
		}else{
			return false;	
		}
	}
	
	public function forgotPassword(){
		$where['fusercode'] = $this->CI->input->get('key',TRUE);
		$where['fuseremail'] = rawurldecode($this->CI->input->get('auth',TRUE));
		if($user = $this->CI->Select_user->get_where($where)){
			$data['fullname'] = ucwords($user['fuserfullname']);
			$data['password'] = random_string('alnum', 10);
			$emails['to'] = $where['fuseremail'];
			$emails['subject'] = '[Go-Kleen] Your New Password';
			$emails['message'] = $this->CI->load->view('email/password',$data,true);
			if($this->CI->user_api->userSendMail($emails)){
				$update['fusercode'] = '';
				$update['fuserpassword'] = md5($data['password']);
				$this->CI->Update_user->updateUser($update,$where);
				return true;
			}	
		}else{
			return false;
		}
	}
}

/* End of file Unzip.php */
/* Location: ./system/libraries/Unzip.php */