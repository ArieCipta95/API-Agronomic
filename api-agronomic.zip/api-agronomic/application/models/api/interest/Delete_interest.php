<?php class Delete_interest extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteVehicles($where,$id){
		$this->db->where($where);
		$this->db->where('fuserid',$id);
		$this->db->delete('tuservehicle'); 
	}
   
	public function deleteUserMeta($where){
		$this->db->where($where);
		$this->db->delete('tusersmeta'); 
	}
}
?>