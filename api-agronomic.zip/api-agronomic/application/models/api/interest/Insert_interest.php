<?php class Insert_interest extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function addNewVehicle($insert){
		$insert['fvehiclecreateddate'] = time();
		$insert['fvehiclemodifieddate'] = time();
		$this->db->set($insert);
		$this->db->insert('tuservehicle');
		return $this->db->insert_id();
	}

	public function cekVehicle($insert){
		$this->db->from('tuservehicle');  
		$this->db->where('fvehicleid',$insert['fvehicleid']);
		$this->db->where('transmission',$insert['transmission']);
		$this->db->where('year',$insert['year']);
		$this->db->where('color',$insert['color']);
		//$this->db->where('fvehicleplatno',$insert['fvehicleplatno']);
		//$this->db->where_in('fuserstatus',array(0,1));
		return $this->db->count_all_results();
	}
  
  	public function addVehicleMeta($insert){
	  	$this->db->set($insert);
	  	$this->db->insert('tvehiclemeta');
	  	return $this->db->insert_id();
  	}
  
  	public function addUserDeviceToken($insert,$userID){
	 	$this->db->set($insert);
	 	$this->db->insert('tuserstoken');
	 	$token_id = $this->db->insert_id();
	  
	  	#update timestamp
	  	$this->db->set('fusertimestamp',time());
      	$this->db->where('fuserid',$userID);
	  	$result = $this->db->update('tusers');
	  	return $token_id;
  }
}
?>