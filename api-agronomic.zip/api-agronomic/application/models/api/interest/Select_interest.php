<?php class Select_interest extends CI_Model {
	var $limit = 10;

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get($offset = FALSE){
		$this->limit = 10;
		if($offset) $offset = ($offset-1)*$this->limit;
			$this->db->distinct();
			$this->db->select('tbrand.*');
			$this->db->where_in('fbrandstatus',array(0,1));
			$this->db->join('tvehicle','tvehicle.fbrandid=tbrand.fbrandid');		
			if($offset!==FALSE)
				$query = $this->db->get('tbrand', $this->limit, $offset);
			else
				$query = $this->db->get('tbrand');

			if($query->num_rows() > 0){
				return $query->result_array();
			}
	}

	public function getBrand_count()
	{
		$this->db->select('*');		
		$query = $this->db->get('tbrand');
		return $query->num_rows();
	}

	public function get_count()
	{
		$this->db->select('*');		
		$query = $this->db->get('tvehicle');
		return $query->num_rows();
	}

	public function getModel($offset,$count=false){
		$this->limit = 10;
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		$this->db->where('fbrandid',$this->input->post('brand_id',TRUE));
		$this->db->where_in('fvehiclestatus',array(0,1));
		if($offset!==FALSE) 
			$query = $this->db->get('tvehicle', $this->limit, $offset);
		else
			$query = $this->db->get('tvehicle');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}

	public function getModel_count()
	{
		$this->db->select('*');		
		$query = $this->db->get('tvehicle');
		return $query->num_rows();
	}

	public function get_meta_where($where,$single=true){
		$this->limit = 10;
		$this->db->select('*');	  
		$this->db->where($where);		
		$this->db->join('tvehiclemeta', 'tvehicle.fvehicleid = tvehiclemeta.fvehicleid');
		$query = $this->db->get('tvehicle');		
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function getUserVehicle($soc,$offset = FALSE,$offset2){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		$this->db->join('tvehicle', 'tvehicle.fvehicleid = tuservehicle.fvehicleid');
		$this->db->join('tbrand', 'tbrand.fbrandid = tvehicle.fbrandid');	
		$this->db->where('tuservehicle.fuserid',$offset2);	
		$this->db->where('tuservehicle.fuserid',$soc);	
		if($offset!==FALSE)		
				$query = $this->db->get('tuservehicle',$this->limit, $offset);
			else
				$query = $this->db->get('tuservehicle');
			
			if ($query->num_rows() > 0){
				return $query->result_array();
			}	
	}

	//adam add vehicle12
	public function getModel2($where){
		$this->db->select('*');
		$this->db->join('tvehicle', 'tvehicle.fvehicleid = tuservehicle.fvehicleid');
		$this->db->join('tbrand', 'tbrand.fbrandid = tvehicle.fbrandid');	
		$this->db->where('fuservehicleid',$where);
		//$this->db->where('tvehicle.fbrandid',$this->input->post('model',TRUE));		
		$query = $this->db->get('tuservehicle');
		
		if ($query->num_rows() > 0){
				return $query->result_array();
			}	
	}

	public function getVehicle($offset = FALSE,$offset2){
		if($offset) $offset = ($offset-1)*$this->limit;
			$this->db->select('*');
			$this->db->join('tvehicle', 'tvehicle.fvehicleid = tuservehicle.fvehicleid');
			$this->db->join('tbrand', 'tbrand.fbrandid = tvehicle.fbrandid');
			$this->db->where('tuservehicle.fuserid',$offset2);				
			if($offset!==FALSE)		
				$query = $this->db->get('tuservehicle',$this->limit, $offset);
			else
				$query = $this->db->get('tuservehicle');
			
			if ($query->num_rows() > 0){
				return $query->result_array();
			}	
	}

	public function getService(){
		$this->db->select('*');
		$query = $this->db->get('tservice');
		return $query->result_array();
	}

	public function getSubService($where){
		$this->db->select('*');
		//$this->db->join('tservice', 'tservice.fserviceid = tsubservice.fserviceid');
		//$this->db->join('taddon', 'taddon.fsubserviceid = tsubservice.fsubserviceid');
		$this->db->where('fserviceid',$where);
		$query = $this->db->get('tsubservice'); 
		return $query->result_array();
	}

	public function getAddon($where){
		$this->db->select('*');
		$this->db->where($where);
		$query = $this->db->get('taddon');
		return $query->result_array();
	}

	public function get_where($where,$field='*'){
		$this->db->select($field);	  
		$this->db->where($where);
		$query = $this->db->get('tinterest');
		if($field=='count(*)'){
			echo $this->db->last_query();
		}
		if ($query->num_rows() > 0){
			return $query->row_array();
		}
	}
  
	public function get_count_meta($meta,$offset = FALSE){
		$this->db->from('tusersmeta');  
		$this->db->where($meta);	
		return $this->db->count_all_results();
	}


	public function get_subservice_price($where){
		$this->db->select('fsubservicespecialprice');
		$this->db->where($where);
		$query = $this->db->get('tsubservice');	
		$a = $query->row_array();
		return $query->row_array();
	}

	public function get_addon_price($where){
		$this->db->select('faddonspecialprice');
		$this->db->where($where);
		$query = $this->db->get('taddon');
		return $query->row_array();
	}

	public function get_subservice_alldata($where){
		$this->db->select('*');
		$this->db->where($where);
		$query = $this->db->get('tsubservice');
		return $query->row_array();
	}

	public function get_addon_alldata($where){
		$this->db->select('*');
		$this->db->where($where);
		$query = $this->db->get('taddon');
		return $query->row_array();
	}

	public function get_vehicle_data($where){
		$this->db->select('*');
		$this->db->where($where);
		$this->db->join('tvehicle', 'tvehicle.fvehicleid = tuservehicle.fvehicleid');
		$query = $this->db->get('tuservehicle');
		return $query->row_array();
	}

	public function get_vehicle_data2($where){
		$this->db->select('*');
		$this->db->where($where);
		$this->db->join('tuservehicle', 'tvehicle.fvehicleid = tuservehicle.fvehicleid');
		$this->db->join('tbrand','tbrand.fbrandid=tvehicle.fbrandid');
		$query = $this->db->get('tvehicle');
		return $query->row_array();
	}

	public function get_user_vehicle_data($where){
		$this->db->select('*');
		$this->db->where($where);
		$query = $this->db->get('tuservehicle');
		return $query->row_array();
	}

	public function getBanner(){
		$this->db->select('*');
		$query = $this->db->get('tslider');
		return $query->result_array();
	}

}
?>