<?php class Insert_media extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
  
	public function addNewMedia($uploads){
		$this->db->set('fuserid',$this->input->post('user_id',TRUE));
		if($this->input->post('caption',TRUE))
			$this->db->set('fmediacaption',$this->input->post('caption',TRUE));
		$this->db->set('fmediapath','/assets/media/uploads/'.$uploads['raw_name'].$uploads['file_ext']);
		$this->db->set('fmediatimestamp',time());
		$this->db->set('fmediatype',$uploads['file_type']);
		$this->db->insert('tmedia');
		$mediaID = $this->db->insert_id();
		return $mediaID;
	}
}
?>