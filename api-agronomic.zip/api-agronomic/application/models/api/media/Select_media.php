<?php class Select_media extends CI_Model {

	var $limit = 5;
  var $order_by = 'fplacename';
  var $order = 'ASC';

  public function __construct()
  {
	parent::__construct();
    $this->load->database();
  }

  public function get($data,$offset = FALSE)
  {
    $this->db->select('*');
	if(isset($data['categoryID']) && $data['categoryID'])
		$this->db->where('fcategoryid',$data['categoryID']);
	elseif(isset($data['tagID']) && $data['tagID'])
		$this->db->where('ftagid',$data['tagID']);
	if(isset($data['order_by']) && isset($data['order'])){
		$this->order_by = $data['order_by'];
		$this->order = $data['order'];
	}
	$this->db->order_by($this->order_by,$this->order);
	$query = $this->db->get('tcategory', $this->limit, $offset);
	if ($query->num_rows() > 0){
	    return $query->result();
	}
  }
  
  public function get_where($where){
	$this->limit = 1;
	$this->db->select('*');	  
	$this->db->where($where);
	$query = $this->db->get('tmedia');
	if ($query->num_rows() > 0){
	    return $query->row_array();
	}
  }
  
  public function get_event($where){
	$this->db->select('*');	
	$this->db->join('teventmeta','teventmeta.fmetavalue = tmedia.fmediaid');  
	$this->db->where('fmetakey','image');
	$this->db->where($where);
	$query = $this->db->get('tmedia');
	if ($query->num_rows() > 0){
	    return $query->result_array();
	}	  
  }
}
?>