<?php class Delete_order extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteClaim($where){
		$this->db->where($where);
		$this->db->delete('tclaimedservice'); 
	}

	public function deleteBooking($where){
		$this->db->where('forderid',$where);
		$this->db->delete('torder');
	}

	public function CancelBooking($where){
		$this->db->where('forderid',$where);
		$this->db->delete('tclaimedservice');
	}
}
?>