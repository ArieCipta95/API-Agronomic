<?php class Insert_order extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function BookingCancel($forderid,$reason){
		$this->db->set('forderid',$forderid);
		$this->db->set('freason',$reason);
		$this->db->insert('tbookingcancel');
		return $this->db->insert_id();
	}

	public function createChassis($insert){
		$this->db->set($insert);
		$this->db->insert('tcondition');
		return $this->db->insert_id();
	}

	public function log_device_id($message,$logtime){
		$this->db->set('flogmessage',$message);
		$this->db->set('flogtime',$logtime);
		$this->db->insert('tlogdevice');
		return $this->db->insert_id();
	}

	public function add_device_id($insert){
		$insert['fdevicecreatetime'] = time();
		$this->db->set($insert);
		$this->db->insert('tdevice');
		return $this->db->insert_id();
	}
	
	public function claimOrder($insert){
		$this->db->replace('tclaimedticket', $insert);
		return true;
	}
	
	public function createOrder($insert){
		//$insert['forderdate2'] = time();
		$this->db->insert('torder', $insert);
		return $this->db->insert_id();
	}
	
	public function createCart($insert){
		//$insert['fbookingdate'] = date("Y-m-d");
		$this->db->insert('tcart', $insert);
		return $this->db->insert_id();
	}
	
	public function createContact($insert){
		$this->db->insert('tordercontact', $insert);
		return $this->db->insert_id();
	}
  
	public function createActivity($insert){
		$this->db->set($insert);
		$this->db->insert('tactivity');
		return $this->db->insert_id();
	}

	//adam
	public function insertCartService($insert){
		$this->db->set($insert);
		$this->db->insert('tcartservice');
		return $this->db->insert_id();
	}

	public function insertCartHour($insert){
		$this->db->set($insert);
		$this->db->insert('tcarthour');
		return $this->db->insert_id();
	}

	public function insertClaimedService($insert){
		$this->db->set($insert);
		$this->db->insert('tclaimedservice');
		return $this->db->insert_id();
	}

	  
}
?>