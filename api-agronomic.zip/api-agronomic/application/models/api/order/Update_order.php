<?php class Update_order extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function Update_fleet($ffleetid,$where){
		$this->db->set('ffleetid',$ffleetid);
		$this->db->where('forderid',$where);
		$result = $this->db->update('tcart');
		return $result;
	}

	public function BookingStatus($update,$where){
		$this->db->set('forderprocessed',$update);
		$this->db->where('forderid',$where);
		$result = $this->db->update('torder');
		return $result;
	}

	public function update_device_id($update,$where){
		$this->db->set($update);
		$this->db->where('fdeviceid',$where);
		$result = $this->db->update('tdevice');
		return $result;
	}

	public function update_userVehicle_order($update,$where){
		$this->db->set('forderdataservice',$update);
		$this->db->where('forderid',$where);
		$result = $this->db->update('torder');
		return $result;
	}

	public function update_userVehicle($update,$where){
		$this->db->set('fcartservice',$update);
		$this->db->where('forderid',$where);
		$result = $this->db->update('tcart');
		return $result;
	}

	public function updateState($update,$where){
		$this->db->set('forderprocessed',$update);
		$this->db->where('forderid',$where);
		$result = $this->db->update('torder');
		return $result;
	}
	
	public function updateClaimOrder($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tclaimedservice');
		return $result;
	}
	
	public function updateOrder($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('torder');
		return $result;
	}
	
	public function updateCart($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tcart');
		return $result;
	}
	
	public function updateTicket($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tticket');
		return $result;
	}
	
	public function updateActivity($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tactivity');
		return $result;
	}

	//adam
	public function updateCartService($update,$where){
		$this->db->set($update);
		$this->db->where('fuserid',$where);
		$result = $this->db->update('tclaimedservice');
		return $result;
	}

	//adam
	public function updateCartSchedule($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tclaimedservice');
		return $result;
	}

	public function update_data_user_vehicle($update,$where){
		$this->db->set($update);
		$this->db->where('fuservehicleid',$where);
		$result = $this->db->update('tuservehicle');
		return $result;
	}


}
?>