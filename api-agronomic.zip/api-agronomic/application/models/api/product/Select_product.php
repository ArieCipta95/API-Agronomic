<?php class Select_product extends CI_Model {

	var $limit = 10;
	var $order_by = 'distance';
	var $order = 'ASC';
	var $distance = '10000';
	var $wideDistance = '50000';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->join('t_kategori', 't_product.fkategoriid = t_kategori.fkategoriid');
		$this->db->where($where);
		$query = $this->db->get('t_product');
		if(!empty($_REQUEST['debug']))echo $this->db->last_query();
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_search($offset = FALSE){
		if($offset) $offset = ($offset-1)*$this->limit;
		$lat = $this->input->post('lat',TRUE);
		$lon = $this->input->post('lon',TRUE);
		$sort_by = ($this->input->post('sort_by',TRUE)) ? $this->input->post('sort_by',TRUE) : $this->order_by;
		$sort = ($this->input->post('sort',TRUE)) ? $this->input->post('sort',TRUE) : $this->order;
		$keyword = $this->input->post('keyword',TRUE);
		
		$this->db->select('*, 
(((ACOS(SIN('.$lat.' * PI() / 180) * SIN(`fproductlat` * PI() / 180) + COS('.$lat.' * PI() / 180) * COS(`fproductlat` * PI() / 180) * COS(('.$lon.' - `fproductlon`) * PI() / 180)) * 180 / PI()) * 60 * 1.1515)*1609.34) AS distance');
		
		$this->db->join('tcategory', 'tcategory.fcategoryid = tproduct.fcategoryid');
		$this->db->join('tprovince', 'tprovince.fprovinceid = tproduct.fprovinceid');
		$this->db->join('tcity', 'tcity.fcityid = tproduct.fcityid');
		$this->db->join('tusers', 'tusers.fuserid = tproduct.fuserid');
		$this->db->join('tmerchant', 'tmerchant.fmerchantid = tproduct.fmerchantid');
		//$this->db->join('tproductmeta', 'tproduct.fproductid = tproductmeta.fproductid','left');
//		$this->db->join('tinterest', 'tproductmeta.fmetavalue = tinterest.finterestid');
		//$this->db->where('fmetakey','interest');
		$this->db->where("(fproductenddate > UNIX_TIMESTAMP(NOW()) or fproductenddate = '' or fproductenddate is null)");
		$this->db->where('tproduct.fproductstatus',1);
		$this->db->where('tmerchant.fmerchantstatus',1);
		$this->db->where('tcategory.fcategorystatus',1);
		if(!empty($this->input->post('province_id',TRUE)))	
			$this->db->where('tproduct.fprovinceid',$this->input->post('province_id',TRUE));
		if(!empty($this->input->post('city_id',TRUE)))
			$this->db->where('tproduct.fcityid',$this->input->post('city_id',TRUE));
		if(!empty($this->input->post('category',TRUE)))
			$this->db->where('tproduct.fcategoryid',$this->input->post('category',TRUE));
		
		$this->db->where('fproductname like '.$this->db->escape('%'.$keyword.'%').' OR fproductdesc like '.$this->db->escape('%'.$keyword.'%').' OR fproductaddress like '.$this->db->escape('%'.$keyword.'%').' OR fcategoryname like '.$this->db->escape('%'.$keyword.'%').' OR fcategorydesc like '.$this->db->escape('%'.$keyword.'%')/*.' OR finterestname like '.$this->db->escape('%'.$keyword.'%').' OR finterestdesc like '.$this->db->escape('%'.$keyword.'%')*/);
		
		switch($sort_by){
			case 'rating':
				$this->db->order_by('fproductrating',$sort);
				break;
			default:
				$this->db->order_by($sort_by,$sort);
				break;	
		}
		
		//$this->db->having("distance <= '".$this->distance."'");
		
		$this->db->group_by('tproduct.fproductid');
		
		if($offset!==FALSE) 
			$query = $this->db->get('tproduct', $this->limit, $offset);
		else
			$query = $this->db->get('tproduct');
		
	//	echo $this->db->last_query();
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	

	//adam
	public function get_current(){

	}
	
	public function get_meta_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where('fmetavalue > UNIX_TIMESTAMP(NOW()) and fmetavalue < UNIX_TIMESTAMP(NOW() + INTERVAL 7 DAY)');
		$this->db->where($where);
		//$this->db->join('tproduct', 'tproduct.fproductid = tproductmeta.fproductid');
		$query = $this->db->get('tproductmeta');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function get_count($by='category')
	{
		$lat = $this->input->post('lat',TRUE);
		$lon = $this->input->post('lon',TRUE);
		$sort_by = ($this->input->post('sort_by',TRUE)) ? $this->input->post('sort_by',TRUE) : $this->order_by;
		$sort = ($this->input->post('sort',TRUE)) ? $this->input->post('sort',TRUE) : $this->order;
		
		$this->db->select('*, 
(((ACOS(SIN('.$lat.' * PI() / 180) * SIN(`fproductlat` * PI() / 180) + COS('.$lat.' * PI() / 180) * COS(`fproductlat` * PI() / 180) * COS(('.$lon.' - `fproductlon`) * PI() / 180)) * 180 / PI()) * 60 * 1.1515)*1609.34) AS distance');
		
		$this->db->join('tcategory', 'tcategory.fcategoryid = tproduct.fcategoryid');
		$this->db->join('tprovince', 'tprovince.fprovinceid = tproduct.fprovinceid');
		$this->db->join('tcity', 'tcity.fcityid = tproduct.fcityid');
		$this->db->join('tusers', 'tusers.fuserid = tproduct.fuserid');
		$this->db->join('tmerchant', 'tmerchant.fmerchantid = tproduct.fmerchantid');
		
		$this->db->where("(fproductenddate > UNIX_TIMESTAMP(NOW()) or fproductenddate = '' or fproductenddate is null)");
		$this->db->where('tproduct.fproductstatus',1);
		$this->db->where('tmerchant.fmerchantstatus',1);
		$this->db->where('tcategory.fcategorystatus',1);
		if(!empty($this->input->post('province_id',TRUE)))	
			$this->db->where('tproduct.fprovinceid',$this->input->post('province_id',TRUE));
		if(!empty($this->input->post('city_id',TRUE)))
			$this->db->where('tproduct.fcityid',$this->input->post('city_id',TRUE));
		if(!empty($this->input->post('category',TRUE)))
			$this->db->where('tproduct.fcategoryid',$this->input->post('category',TRUE));
		
		switch($by){
			case 'featured':
				$this->db->where('fproductfeatured',1);
				break;
			default:break;	
		}
		
		switch($sort_by){
			case 'rating':
				$this->db->order_by('fproductrating',$sort);
				break;
			default:
				$this->db->order_by($sort_by,$sort);
				break;	
		}
		
		//$this->db->having("distance <= '".$this->distance."'");
		
		$this->db->group_by('tproduct.fproductid');
		$query = $this->db->get('tproduct');
		return $query->num_rows();
	}
	
	public function get_search_count(){
		
		$lat = $this->input->post('lat',TRUE);
		$lon = $this->input->post('lon',TRUE);
		$sort_by = ($this->input->post('sort_by',TRUE)) ? $this->input->post('sort_by',TRUE) : $this->order_by;
		$sort = ($this->input->post('sort',TRUE)) ? $this->input->post('sort',TRUE) : $this->order;
		$keyword = $this->input->post('keyword',TRUE);
		
		$this->db->select('*, 
(((ACOS(SIN('.$lat.' * PI() / 180) * SIN(`fproductlat` * PI() / 180) + COS('.$lat.' * PI() / 180) * COS(`fproductlat` * PI() / 180) * COS(('.$lon.' - `fproductlon`) * PI() / 180)) * 180 / PI()) * 60 * 1.1515)*1609.34) AS distance');
		
		$this->db->join('tcategory', 'tcategory.fcategoryid = tproduct.fcategoryid');
		$this->db->join('tprovince', 'tprovince.fprovinceid = tproduct.fprovinceid');
		$this->db->join('tcity', 'tcity.fcityid = tproduct.fcityid');
		$this->db->join('tusers', 'tusers.fuserid = tproduct.fuserid');
		$this->db->join('tmerchant', 'tmerchant.fmerchantid = tproduct.fmerchantid');
		//$this->db->join('tproductmeta', 'tproduct.fproductid = tproductmeta.fproductid','left');
//		$this->db->join('tinterest', 'tproductmeta.fmetavalue = tinterest.finterestid');
		//$this->db->where('fmetakey','interest');
		$this->db->where("(fproductenddate > UNIX_TIMESTAMP(NOW()) or fproductenddate = '' or fproductenddate is null)");
		$this->db->where('tproduct.fproductstatus',1);
		$this->db->where('tmerchant.fmerchantstatus',1);
		$this->db->where('tcategory.fcategorystatus',1);
		if(!empty($this->input->post('province_id',TRUE)))	
			$this->db->where('tproduct.fprovinceid',$this->input->post('province_id',TRUE));
		if(!empty($this->input->post('city_id',TRUE)))
			$this->db->where('tproduct.fcityid',$this->input->post('city_id',TRUE));
		if(!empty($this->input->post('category',TRUE)))
			$this->db->where('tproduct.fcategoryid',$this->input->post('category',TRUE));
		
		$this->db->where('fproductname like '.$this->db->escape('%'.$keyword.'%').' OR fproductdesc like '.$this->db->escape('%'.$keyword.'%').' OR fproductaddress like '.$this->db->escape('%'.$keyword.'%').' OR fcategoryname like '.$this->db->escape('%'.$keyword.'%').' OR fcategorydesc like '.$this->db->escape('%'.$keyword.'%')/*.' OR finterestname like '.$this->db->escape('%'.$keyword.'%').' OR finterestdesc like '.$this->db->escape('%'.$keyword.'%')*/);
		
		switch($sort_by){
			case 'rating':
				$this->db->order_by('fproductrating',$sort);
				break;
			default:
				$this->db->order_by($sort_by,$sort);
				break;	
		}
		
		//$this->db->having("distance <= '".$this->distance."'");
		
		$this->db->group_by('tproduct.fproductid');
		
		$query = $this->db->get('tproduct');
		return $query->num_rows();
	}
	
	public function get_country($offset,$count=false){
		$this->limit = 30;
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		$this->db->where('fcountrynumber !=', 0);
		$this->db->order_by('fcountryname','ASC');
		if($offset!==FALSE) 
			$query = $this->db->get('tcountry', $this->limit, $offset);
		else
			$query = $this->db->get('tcountry');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}
	
	public function get_country_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		
		$query = $this->db->get('tcountry');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}
	
	public function get_province($offset,$count=false){
		$this->limit = 30;
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		$this->db->where('fcountrycode',$this->input->post('country_code',TRUE));
		$this->db->order_by('fprovincename','ASC');
		if($offset!==FALSE) 
			$query = $this->db->get('tprovince', $this->limit, $offset);
		else
			$query = $this->db->get('tprovince');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}
	
	public function get_province_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		$this->db->order_by('fprovincename','ASC');
			$query = $this->db->get('tprovince');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}
	
	public function get_city($offset,$count=false){
		$this->limit = 30;
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		$this->db->where('fprovinceid',$this->input->post('province_id',TRUE));
		$this->db->order_by('fcityname','ASC');
		if($offset!==FALSE) 
			$query = $this->db->get('tcity', $this->limit, $offset);
		else
			$query = $this->db->get('tcity');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}
	
	public function get_tickets(){
		$this->db->select('*');	
		$this->db->where('fproductid',$this->input->post('product_id',TRUE));
		$this->db->where('fticketstock >= 1');
		if(!empty($this->input->post('schedule',TRUE)))
			$this->db->where('fscheduleid',$this->input->post('schedule',TRUE));
		$query = $this->db->get('tticket');
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	
	//adam
	public function get_ticket_where($where,$single=true){
		$this->db->select('*');	
		$this->db->where($where);
		$query = $this->db->get('tticket');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();	
			else
				return $query->result_array();	
		}
	}
	
	public function get_claimed($where,$count=false){		
		$this->db->select('*');	
		$this->db->where($where);
		$query = $this->db->get('tclaimedticket');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $query->num_rows();
		}
	}
	
	public function get_activity($where,$count=false){		
		$this->db->select('*');	
		$this->db->where($where);
		$query = $this->db->get('tactivity');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $query->num_rows();
		}
	}
	
	public function get_review($offset,$count=false){
		$this->limit = 30;
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort = ($this->input->post('sort',TRUE)) ? $this->input->post('sort',TRUE) : 'DESC';
		switch($this->input->post('sort_by',TRUE)){
			case 'higher_rating':
				$sort_by = 'freviewrating';	
				$sort = 'DESC';
				break;
			case 'lowest_rating':
				$sort_by = 'freviewrating';	
				$sort = 'ASC';
				break;
			case 'rating':
				$sort_by = 'freviewrating';	
				break;
			default:
				$sort_by = 'freviewdate';	
				break;
		}
		$this->db->select('freviewid,freviewtext,freviewrating,freviewdate,treview.fuserid,fuserfullname,fuserbirthdate,fuseremail,fuserprofpic,fproductrating,fuserparentid,fuserstatus,fproductrating');
		$this->db->join('tusers', 'tusers.fuserid = treview.fuserid');
		$this->db->join('tproduct', 'tproduct.fproductid = treview.fproductid');
		$this->db->where('treview.fproductid',$this->input->post('product_id',TRUE));
		$this->db->where('freviewstatus',1);
		$this->db->order_by($sort_by,$sort);
		if($offset!==FALSE) 
			$query = $this->db->get('treview', $this->limit, $offset);
		else
			$query = $this->db->get('treview');
			
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $query->num_rows();
		}	
	}
	
	public function get_review_where($where,$count=false){		
		$this->db->select('*');	
		$this->db->where($where);
		$this->db->where('freviewstatus',1);
		$this->db->join('tusers', 'tusers.fuserid = treview.fuserid');
		$this->db->join('tproduct', 'tproduct.fproductid = treview.fproductid');
		$query = $this->db->get('treview');
		
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			elseif($count=='single')
				return $query->row_array();
			else
				return $query->num_rows();
		}
	}
}
?>