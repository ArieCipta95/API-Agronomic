<?php class Delete_addon extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteAddon($addon){
		$this->db->where($addon);
		$this->db->delete('taddon'); 
	}
   
	public function deleteAddonMeta($meta){
		$this->db->where($meta);
		$this->db->delete('taddonmeta'); 
	}
   
}
?>