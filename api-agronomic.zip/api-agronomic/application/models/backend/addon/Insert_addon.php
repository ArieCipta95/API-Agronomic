<?php class Insert_addon extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
  public function addNewAddon($addon){
	  $this->db->set($addon);
	  $this->db->insert('taddon');
	  return $this->db->insert_id();
  }
	
}
?>