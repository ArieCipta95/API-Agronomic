<?php class Select_addon extends CI_Model {
	
	var $limit = 20;
	var $order_by = 'faddonid';
	var $order = 'ASC';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get_addon($offset = FALSE){
	
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = ($this->input->get_post('sort_by',TRUE)) ? $this->input->get_post('sort_by',TRUE) : $this->order_by;
		switch($sort_by){
			case 'id': $sort_by = 'faddonid';break;
			case 'name': $sort_by = 'faddonname';break;
			default: $sort_by = $this->order_by;break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		
		$this->db->select('*');
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'faddonname like '.$this->db->escape('%'.$keyword.'%').' OR faddondesc like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		$this->db->order_by($sort_by,$sort);
		
		if($offset!==FALSE) 
			$query = $this->db->get('taddon', $this->limit, $offset);
		else
			$query = $this->db->get('taddon');
		
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	
	public function get_addon_where($where,$single=true){
		$this->db->select('*');
		
		$this->db->where($where);
		
		$query = $this->db->get('taddon');
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
		$this->db->order_by('faddonid');
	}

	public function get_addon_count()
	{
		
		$this->db->select('*');
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'faddonname like '.$this->db->escape('%'.$keyword.'%').' OR faddondesc like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		$query = $this->db->get('taddon');
		return $query->num_rows();
	}
}
?>