<?php class Update_addon extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function updateAddon($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('taddon');
//		echo $this->db->last_query();
		return true;
	}
	
	/*public function updateAddonMeta($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('taddonmeta');
		return $result;
	}*/
}
?>