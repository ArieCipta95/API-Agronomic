<?php class Delete_brand extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteBrand($brand){
		$this->db->where($brand);
		$this->db->delete('tbrand'); 
	}
   
	public function deleteBrandMeta($meta){
		$this->db->where($meta);
		$this->db->delete('tbrandmeta'); 
	}
   
}
?>