<?php class Insert_brand extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
  public function addNewBrand($brand){
	  $this->db->set($brand);
	  $this->db->insert('tbrand');
	  return $this->db->insert_id();
  }
	
}
?>