<?php class Select_brand extends CI_Model {
	
	var $limit = 20;
	var $order_by = 'tbrand.fbrandid';
	var $order = 'ASC';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get($offset = FALSE){
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = ($this->input->get_post('sort_by',TRUE)) ? $this->input->get_post('sort_by',TRUE) : $this->order_by;
		switch($sort_by){
			case 'brand_name': $sort_by = 'fbrandname';break;
			case 'logo': $sort_by = 'fbrandname';break;
			case 'totalbrand': $sort_by = 'fbrandtotalbrand';break;
			case 'status': $sort_by = 'fbrandstatus';break;
			default: $sort_by = $this->order_by;break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		$curStatus = $this->input->get_post('status',true);
		
		if(!empty($curStatus) && $curStatus!='') $this->db->where('fbrandstatus',$curStatus);
		if(!empty($this->input->get_post('my',TRUE))){
			$this->db->where('DATE_FORMAT( FROM_UNIXTIME(  `fbranddate` ),  "%m%y" ) = '.$this->input->get_post('my',TRUE));	
		}
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fbrandslug like '.$this->db->escape('%'.$keyword.'%').' OR fbrandphone like '.$this->db->escape('%'.$keyword.'%').' OR fbranddesc like '.$this->db->escape('%'.$keyword.'%').' OR fbrandemail like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		$this->db->group_by('tbrand.fbrandid');
		$this->db->order_by($sort_by,$sort);
		
		if($offset!==FALSE) 
			$query = $this->db->get('tbrand', $this->limit, $offset);
		else
			$query = $this->db->get('tbrand');
			
		//uecho $this->db->last_query();
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}

	public function get_count()
	{		
		$this->db->select('*');

		$curStatus = $this->input->get_post('status',true);
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fbrandslug like '.$this->db->escape('%'.$keyword.'%').' OR fbrandphone like '.$this->db->escape('%'.$keyword.'%').' OR fbranddesc like '.$this->db->escape('%'.$keyword.'%').' OR fbrandemail like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		$this->db->group_by('tbrand.fbrandid');
		$query = $this->db->get('tbrand');
		return $query->num_rows();
	}
	
	public function get_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$query = $this->db->get('tbrand');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_count_where($where='',$single=true){
		$this->db->select('count(distinct(tbrand.fbrandid)) as total');	  
		
		if(!empty($where))$this->db->where($where);
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'tbrand.fbrandid like '.$this->db->escape('%'.$keyword.'%').' OR tbrand.fbrandslug like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($where)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		$query = $this->db->get('tbrand');
		//echo $this->db->last_query();
		return $query->row_array();
	}
}
?>