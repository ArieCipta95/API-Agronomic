<?php class Update_brand extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function updateBrand($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tbrand');
//		echo $this->db->last_query();
		return true;
	}
	
	public function updateBrandMeta($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tbrandmeta');
		return $result;
	}
}
?>