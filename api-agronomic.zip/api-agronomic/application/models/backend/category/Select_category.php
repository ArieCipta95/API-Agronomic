<?php class Select_category extends CI_Model {

	 var $limit = 10;
	 var $sort = 'ASC';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get(){
		if($this->input->post('sort',TRUE))
			$this->sort = $this->input->post('sort',TRUE);
		$this->db->select('*');
		$this->db->order_by('fcategoryorder',$this->sort);
			$query = $this->db->get('tcategory');
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	
	public function get_where($where,$field='*'){
		$this->db->select($field);	  
		$this->db->where($where);
		$query = $this->db->get('tusers');
		if($field=='count(*)'){
			echo $this->db->last_query();
		}
		if ($query->num_rows() > 0){
			return $query->row_array();
		}
	}

	public function get_count()
	{
		$this->db->from('tcategory');
		$this->db->where('fcategorystatus',1);
		return $this->db->count_all_results();
	}
}
?>