<?php class Delete_coupon extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteCoupon($coupon){
		$this->db->where($coupon);
		$this->db->delete('tcoupon'); 
	}
   
	public function deleteCouponMeta($meta){
		$this->db->where($meta);
		$this->db->delete('tcouponmeta'); 
	}
   
}
?>