<?php class Insert_coupon extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
  public function addNewCoupon($coupon){
	  $this->db->set($coupon);
	  $this->db->insert('tcoupon');
	  return $this->db->insert_id();
  }
  
}
?>