<?php class Select_vehicle extends CI_Model {
	
	var $limit = 20;
	var $order_by = 'tvehicle.fvehicleid';
	var $order = 'ASC';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get($offset = FALSE){
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = ($this->input->get_post('sort_by',TRUE)) ? $this->input->get_post('sort_by',TRUE) : $this->order_by;
		switch($sort_by){
			case 'brandname': $sort_by = 'fbrandname';break;
			case 'vehiclename': $sort_by = 'fvehiclename';break;
			case 'status': $sort_by = 'fvehiclestatus';break;
			default: $sort_by = $this->order_by;break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		$curStatus = $this->input->get_post('status',true);
		
		$this->db->select('*, count(fvehicleid) as fvehicletotal');	
		
		$this->db->join('tbrand', 'tbrand.fbrandid = tvehicle.fbrandid');

		if(!empty($curStatus) && $curStatus!='') $this->db->where('fvehiclestatus',$curStatus);
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'tvehicle.fvehicleid like '.$this->db->escape('%'.$keyword.'%').' OR tvehicle.fbrandid like '.$this->db->escape('%'.$keyword.'%').' OR fvehicledesc like '.$this->db->escape('%'.$keyword.'%').' OR tbrand.fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fvehiclename like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);

		}
		$whereBrand = 'tbrand.fbrandstatus = 1';
		$this->db->where($whereBrand);
		$this->db->group_by('tvehicle.fvehicleid');
		$this->db->order_by($sort_by,$sort);
		
		if($offset!==FALSE) 
			$query = $this->db->get('tvehicle', $this->limit, $offset);
		else
			$query = $this->db->get('tvehicle');
			
		//echo $this->db->last_query();
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}

	public function get_count()
	{		
		$this->db->select('*');
		$this->db->join('tbrand', 'tbrand.fbrandid = tvehicle.fbrandid');
		$curStatus = $this->input->get_post('status',true);	
		if(!empty($curStatus) && $curStatus!='') $this->db->where('fvehiclestatus',$curStatus);
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'tvehicle.fvehicleid like '.$this->db->escape('%'.$keyword.'%').' OR tvehicle.fbrandid like '.$this->db->escape('%'.$keyword.'%').' OR fvehicledesc like '.$this->db->escape('%'.$keyword.'%').' OR tbrand.fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fvehiclename like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		$whereBrand = 'tbrand.fbrandstatus = 1';
		$this->db->where($whereBrand);
		$this->db->group_by('tvehicle.fvehicleid');
		$query = $this->db->get('tvehicle');
		//echo $this->db->last_query();
		return $query->num_rows();
	}
	
	public function get_vehicle_brand_where($where,$single=true){
		$this->db->select('*');
		$this->db->join('tbrand', 'tbrand.fbrandid = tvehicle.fbrandid');
		$this->db->where($where);
		$this->db->where('fbrandstatus != 0');
		$this->db->group_by('tvehicle.fbrandid');
		$query = $this->db->get('tvehicle');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();	
			else
				return $query->result_array();	
		}
	}
	
	public function get_where($where,$single=true){
		
		$this->db->select('*');	  
		$this->db->where($where);
		
		$query = $this->db->get('tvehicle');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function get_meta_where($where,$single=true){ 
		$this->db->select('*');	  
		$this->db->where($where);
		$this->db->join('tvehicle', 'tvehicle.fvehicleid = tvehiclemeta.fvehicleid');
		$query = $this->db->get('tvehiclemeta');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_count_where($where='',$single=true){
		$this->db->select('count(distinct(tvehicle.fbrandid)) as total');	  
		$this->db->join('tbrand', 'tbrand.fbrandid = tvehicle.fbrandid');
		if(!empty($where))$this->db->where($where);
		if(!empty($this->input->get_post('my',TRUE))){
			$this->db->where('DATE_FORMAT( FROM_UNIXTIME(  `forderdate` ),  "%m%y" ) = '.$this->input->get_post('my',TRUE));	
		}
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'tvehicle.fvehicleid like '.$this->db->escape('%'.$keyword.'%').' OR tvehicle.fbrandid like '.$this->db->escape('%'.$keyword.'%').' OR fvehicledesc like '.$this->db->escape('%'.$keyword.'%').' OR tbrand.fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fvehiclename like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		
		$query = $this->db->get('tvehicle');
		//echo $this->db->last_query();
		return $query->row_array();
	}
	
	public function vehicle_get_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$query = $this->db->get('tvehicle');
		
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function get_vehicle_brand(){
		$text = '';
		switch($status){
			case 1:$text = 'Active';break;
			case 2:$text = 'Featured';break;
			case 3:$text = 'Not Active';break;
			default:$text = 'All';break;
		}
		return $text;
	}
	
	public function vehicle_status($status){
		$text = '';
		switch($status){
			case 1:$text = 'Active';break;
			case 2:$text = 'Featured';break;
			case 3:$text = 'Not Active';break;
			default:$text = 'All';break;
		}
		return $text;
	}
	
	public function vehicle_dashboard($time='-30 days',$field='sum(fordertotalprice) as totalsales',$status=array(3)){
		$this->db->select($field);	  
		$this->db->where('DATE_FORMAT(FROM_UNIXTIME(  `forderdate` ), "%m%Y" ) = '.$time);
		$this->db->where_in('fvehiclestatus',$status);
		$query = $this->db->get('tvehicle');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			return $query->row_array();	
		}
	}
}
?>