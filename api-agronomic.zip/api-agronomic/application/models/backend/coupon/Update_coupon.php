<?php class Update_vehicle extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function updateVehicle($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tvehicle');
//		echo $this->db->last_query();
		return true;
	}
	
	public function updateVehicleMeta($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tvehiclemeta');
//		echo $this->db->last_query();
		return $result;
	}
}
?>