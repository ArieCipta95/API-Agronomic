<?php class Delete_crew extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteCrew($crew){
		$this->db->where($crew);
		$this->db->delete('tcrew'); 
	}
   
	public function deleteCrewMeta($meta){
		$this->db->where($meta);
		$this->db->delete('tcrewmeta'); 
	}
   
}
?>