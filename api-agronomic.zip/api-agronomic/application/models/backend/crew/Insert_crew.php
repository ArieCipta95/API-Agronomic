<?php class Insert_crew extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
  public function addNewCrew($crew){
	  $this->db->set($crew);
	  $this->db->insert('tcrew');
	  return $this->db->insert_id();
  }
	
}
?>