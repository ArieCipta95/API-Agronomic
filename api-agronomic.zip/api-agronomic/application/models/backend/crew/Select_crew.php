<?php class Select_crew extends CI_Model {
	
	var $limit = 20;
	var $order_by = 'tcrew.fcrewid';
	var $crew = 'ASC';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get($offset = FALSE){
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = ($this->input->get_post('sort_by',TRUE)) ? $this->input->get_post('sort_by',TRUE) : $this->order_by;
		switch($sort_by){
			case 'crew_name': $sort_by = 'fcrewfirstname';break;
			case 'logo': $sort_by = 'fcrewfirstname';break;
			case 'totalvehicle': $sort_by = 'fcrewtotalvehicle';break;
			case 'status': $sort_by = 'fcrewstatus';break;
			default: $sort_by = $this->order_by;break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->crew;
		$curStatus = $this->input->get_post('status',true);
		
		if(!empty($curStatus) && $curStatus!='') $this->db->where('fcrewstatus',$curStatus);
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fcrewid like '.$this->db->escape('%'.$keyword.'%').' OR fcrewfirstname like '.$this->db->escape('%'.$keyword.'%').' OR fcrewlastname like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($where)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		$this->db->group_by('tcrew.fcrewid');
		$this->db->order_by($sort_by,$sort);
		
		if($offset!==FALSE) 
			$query = $this->db->get('tcrew', $this->limit, $offset);
		else
			$query = $this->db->get('tcrew');
			
		//uecho $this->db->last_query();
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	
	public function get_crew_fleet_where($where,$single=true){
		$this->db->select('*');
		$this->db->join('tfleet', 'tfleet.ffleetid = tcrew.ffleetid');
		$this->db->where($where);
		$this->db->where('ffleetstatus != 0');
		$this->db->group_by('tcrew.ffleetid');
		$query = $this->db->get('tcrew');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();	
			else
				return $query->result_array();	
		}
	}

	public function get_count()
	{		
		$this->db->select('*');

		$curStatus = $this->input->get_post('status',true);
		
		if(!empty($curStatus) && $curStatus!='') $this->db->where('fcrewstatus',$curStatus);
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fcrewid like '.$this->db->escape('%'.$keyword.'%').' OR fcrewfirstname like '.$this->db->escape('%'.$keyword.'%').' OR fcrewlastname like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($where)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		$this->db->group_by('tcrew.fcrewid');
		$query = $this->db->get('tcrew');
		return $query->num_rows();
	}
	
	
	public function get_claimed_where($where,$single=true,$exp=true){
		$this->db->select('*');	  
		$this->db->where($where);
		if($exp) $this->db->where('fexpireddate > UNIX_TIMESTAMP(NOW())');
		$query = $this->db->get('tclaimedticket');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_cart_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$query = $this->db->get('tcart');
//		echo $this->db->last_query();//
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$query = $this->db->get('tcrew');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_count_where($where='',$single=true){
		$this->db->select('count(distinct(tcrew.fcrewid)) as total');	  
		
		if(!empty($where))$this->db->where($where);
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fcrewid like '.$this->db->escape('%'.$keyword.'%').' OR fcrewfirstname like '.$this->db->escape('%'.$keyword.'%').' OR fcrewlastname like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($where)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		$query = $this->db->get('tcrew');
		//echo $this->db->last_query();
		return $query->row_array();
	}
	
	public function order_get_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$query = $this->db->get('tcrew');
		
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function order_option($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$this->db->where_in('foptionstatus',1);
		$query = $this->db->get('toption');
		
		if ($query->num_rows() > 0){
			if($single){
				$row = $query->row_array();
				return $row['foptionvalue'];
			}else
				return $query->result_array();
		}
	}
	
	public function order_status($status){
		$text = '';
		switch($status){
			case 4:$text = 'validated';break;
			case 3:$text = 'purchased';break;
			case 2:$text = 'pending';break;
			default:$text = 'incomplete';break;
		}
		return $text;
	}
	
	public function order_dashboard($time='-30 days',$field='sum(fordertotalprice) as totalsales',$status=array(3)){
		$this->db->select($field);	  
		$this->db->where('DATE_FORMAT(FROM_UNIXTIME(  `forderdate` ), "%m%Y" ) = '.$time);
		$this->db->where_in('forderprocessed',$status);
		$query = $this->db->get('tcrew');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			return $query->row_array();	
		}
	}
}
?>