<?php class Update_crew extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function updateCrew($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tcrew');
//		echo $this->db->last_query();
		return true;
	}
	
	/*public function updateCrewMeta($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tcrewmeta');
		return $result;
	}*/
}
?>