<?php class Delete_event extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteEvent($event){
		$this->db->where($event);
		$this->db->delete('tevent'); 
	}
   
	public function deleteEventMeta($meta){
		$this->db->where($meta);
		$this->db->delete('teventmeta'); 
	}
   
	public function deleteTicket($ticket){
		$this->db->where($ticket);
		$this->db->delete('tticket'); 
	}
}
?>