<?php class Insert_event extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
  public function addEvent($event){
	  $this->db->set($event);
	  $this->db->insert('tevent');
	  return $this->db->insert_id();
  }
	
  public function addTickets($insert){
	  $this->db->set($insert);
	  $this->db->insert('tticket');
	  return $this->db->insert_id();
  }
	
  public function addEventMeta($insert){
	  $this->db->set($insert);
	  $this->db->insert('teventmeta');
	  return $this->db->insert_id();
  }
}
?>