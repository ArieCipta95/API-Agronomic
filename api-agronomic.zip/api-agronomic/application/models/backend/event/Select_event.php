<?php class Select_event extends CI_Model {

	var $limit = 20;
	var $order_by = 'feventname';
	var $order = 'ASC';
	var $distance = '10000';
	var $wideDistance = '50000';
	var $countryCode = 'ID';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get($offset = FALSE,$by='category'){
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = ($this->input->get_post('sort_by',TRUE)) ? $this->input->get_post('sort_by',TRUE) : $this->order_by;
		switch($sort_by){
			case 'stock': $sort_by = 'feventtotalstock';break;
			case 'price': $sort_by = 'feventprice';break;
			case 'merchant': $sort_by = 'fmerchantname';break;
			case 'special_price': $sort_by = 'feventspecialprice';break;
			case 'date': $sort_by = 'feventcreateddate';break;
			case 'featured': $sort_by = 'feventfeatured';break;
			case 'status': $sort_by = 'feventstatus';break;
			default: $sort_by = $this->order_by;break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		
		$this->db->select('*');
		
		$this->db->join('tcategory', 'tcategory.fcategoryid = tevent.fcategoryid');
		$this->db->join('tprovince', 'tprovince.fprovinceid = tevent.fprovinceid');
		$this->db->join('tcity', 'tcity.fcityid = tevent.fcityid');
		$this->db->join('tusers', 'tusers.fuserid = tevent.fuserid');
		$this->db->join('tmerchant', 'tmerchant.fmerchantid = tevent.fmerchantid');
		
		if(!empty($this->input->get_post('province_id',TRUE)))	
			$this->db->where('tevent.fprovinceid',$this->input->get_post('province_id',TRUE));
		if(!empty($this->input->get_post('city_id',TRUE)))
			$this->db->where('tevent.fcityid',$this->input->get_post('city_id',TRUE));
		if(!empty($this->input->get_post('category',TRUE)))
			$this->db->where('tevent.fcategoryid',$this->input->get_post('category',TRUE));
		if(!empty($this->input->get_post('merchant_id',TRUE)))
			$this->db->where('tevent.fmerchantid',$this->input->get_post('merchant_id',TRUE));
		
		$this->db->order_by($sort_by,$sort);
		
		//$this->db->having("distance <= '".$this->distance."'");
		
		$this->db->group_by('tevent.feventid');
		
		if($offset!==FALSE) 
			$query = $this->db->get('tevent', $this->limit, $offset);
		else
			$query = $this->db->get('tevent');
		
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	
	public function get_search($offset = FALSE){
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = ($this->input->get_post('sort_by',TRUE)) ? $this->input->get_post('sort_by',TRUE) : $this->order_by;
		switch($sort_by){
			case 'stock': $sort_by = 'feventtotalstock';break;
			case 'price': $sort_by = 'feventprice';break;
			case 'merchant': $sort_by = 'fmerchantname';break;
			case 'special_price': $sort_by = 'feventspecialprice';break;
			case 'date': $sort_by = 'feventcreateddate';break;
			case 'featured': $sort_by = 'feventfeatured';break;
			case 'status': $sort_by = 'feventstatus';break;
			default: $sort_by = $this->order_by;break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		$keyword = $this->input->get_post('s',TRUE);
		
		$this->db->select('*');
		
		$this->db->join('tcategory', 'tcategory.fcategoryid = tevent.fcategoryid');
		$this->db->join('tprovince', 'tprovince.fprovinceid = tevent.fprovinceid');
		$this->db->join('tcity', 'tcity.fcityid = tevent.fcityid');
		$this->db->join('tusers', 'tusers.fuserid = tevent.fuserid');
		$this->db->join('tmerchant', 'tmerchant.fmerchantid = tevent.fmerchantid');
		//$this->db->join('teventmeta', 'tevent.feventid = teventmeta.feventid','left');
//		$this->db->join('tinterest', 'teventmeta.fmetavalue = tinterest.finterestid');
		//$this->db->where('fmetakey','interest');
		
		if(!empty($this->input->get_post('province_id',TRUE)))	
			$this->db->where('tevent.fprovinceid',$this->input->get_post('province_id',TRUE));
		if(!empty($this->input->get_post('city_id',TRUE)))
			$this->db->where('tevent.fcityid',$this->input->get_post('city_id',TRUE));
		if(!empty($this->input->get_post('category',TRUE)))
			$this->db->where('tevent.fcategoryid',$this->input->get_post('category',TRUE));
		if(!empty($this->input->get_post('merchant_id',TRUE)))
			$this->db->where('tevent.fmerchantid',$this->input->get_post('merchant_id',TRUE));
		
		$this->db->where('feventname like '.$this->db->escape('%'.$keyword.'%').' OR feventdesc like '.$this->db->escape('%'.$keyword.'%').' OR feventaddress like '.$this->db->escape('%'.$keyword.'%').' OR fcategoryname like '.$this->db->escape('%'.$keyword.'%').' OR fcategorydesc like '.$this->db->escape('%'.$keyword.'%').' OR fmerchantname like '.$this->db->escape('%'.$keyword.'%'));
		
		$this->db->order_by($sort_by,$sort);
		
		//$this->db->having("distance <= '".$this->distance."'");
		
		$this->db->group_by('tevent.feventid');
		
		if($offset!==FALSE) 
			$query = $this->db->get('tevent', $this->limit, $offset);
		else
			$query = $this->db->get('tevent');
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	
	public function get_where($where,$single=true){
		$this->db->select('*');
		
		$this->db->where($where);
		
		//$this->db->having("distance <= '".$this->distance."'");
		
		$this->db->group_by('tevent.feventid');
		$query = $this->db->get('tevent');
		
		//echo $this->db->last_query();die();
		
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_meta_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$this->db->join('tevent', 'tevent.feventid = teventmeta.feventid');
		$query = $this->db->get('teventmeta');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function get_count($by='category')
	{
		$lat = $this->input->post('lat',TRUE);
		$lon = $this->input->post('lon',TRUE);
		$sort_by = ($this->input->post('sort_by',TRUE)) ? $this->input->post('sort_by',TRUE) : $this->order_by;
		$sort = ($this->input->post('sort',TRUE)) ? $this->input->post('sort',TRUE) : $this->order;
		
		$this->db->select('*');
		
		$this->db->join('tcategory', 'tcategory.fcategoryid = tevent.fcategoryid');
		$this->db->join('tprovince', 'tprovince.fprovinceid = tevent.fprovinceid');
		$this->db->join('tcity', 'tcity.fcityid = tevent.fcityid');
		$this->db->join('tusers', 'tusers.fuserid = tevent.fuserid');
		$this->db->join('tmerchant', 'tmerchant.fmerchantid = tevent.fmerchantid');
		
		if(!empty($this->input->get_post('province_id',TRUE)))	
			$this->db->where('tevent.fprovinceid',$this->input->get_post('province_id',TRUE));
		if(!empty($this->input->get_post('city_id',TRUE)))
			$this->db->where('tevent.fcityid',$this->input->get_post('city_id',TRUE));
		if(!empty($this->input->get_post('category',TRUE)))
			$this->db->where('tevent.fcategoryid',$this->input->get_post('category',TRUE));
		if(!empty($this->input->get_post('merchant_id',TRUE)))
			$this->db->where('tevent.fmerchantid',$this->input->get_post('merchant_id',TRUE));
		
		switch($sort_by){
			case 'rating':
				$this->db->order_by('feventrating',$sort);
				break;
			default:
				$this->db->order_by($sort_by,$sort);
				break;	
		}
		
		//$this->db->having("distance <= '".$this->distance."'");
		
		$this->db->group_by('tevent.feventid');
		$query = $this->db->get('tevent');
		return $query->num_rows();
	}
	
	public function get_search_count(){
		
		$lat = $this->input->post('lat',TRUE);
		$lon = $this->input->post('lon',TRUE);
		$sort_by = ($this->input->post('sort_by',TRUE)) ? $this->input->post('sort_by',TRUE) : $this->order_by;
		$sort = ($this->input->post('sort',TRUE)) ? $this->input->post('sort',TRUE) : $this->order;
		$keyword = $this->input->get_post('s',TRUE);
		
		$this->db->select('*');
		
		$this->db->join('tcategory', 'tcategory.fcategoryid = tevent.fcategoryid');
		$this->db->join('tprovince', 'tprovince.fprovinceid = tevent.fprovinceid');
		$this->db->join('tcity', 'tcity.fcityid = tevent.fcityid');
		$this->db->join('tusers', 'tusers.fuserid = tevent.fuserid');
		$this->db->join('tmerchant', 'tmerchant.fmerchantid = tevent.fmerchantid');
		//$this->db->join('teventmeta', 'tevent.feventid = teventmeta.feventid','left');
//		$this->db->join('tinterest', 'teventmeta.fmetavalue = tinterest.finterestid');
		//$this->db->where('fmetakey','interest');
		
		if(!empty($this->input->get_post('province_id',TRUE)))	
			$this->db->where('tevent.fprovinceid',$this->input->get_post('province_id',TRUE));
		if(!empty($this->input->get_post('city_id',TRUE)))
			$this->db->where('tevent.fcityid',$this->input->get_post('city_id',TRUE));
		if(!empty($this->input->get_post('category',TRUE)))
			$this->db->where('tevent.fcategoryid',$this->input->get_post('category',TRUE));
		if(!empty($this->input->get_post('merchant_id',TRUE)))
			$this->db->where('tevent.fmerchantid',$this->input->get_post('merchant_id',TRUE));
		
		$this->db->where('feventname like '.$this->db->escape('%'.$keyword.'%').' OR feventdesc like '.$this->db->escape('%'.$keyword.'%').' OR feventaddress like '.$this->db->escape('%'.$keyword.'%').' OR fcategoryname like '.$this->db->escape('%'.$keyword.'%').' OR fcategorydesc like '.$this->db->escape('%'.$keyword.'%').' OR fmerchantname like '.$this->db->escape('%'.$keyword.'%'));
		
		switch($sort_by){
			case 'rating':
				$this->db->order_by('feventrating',$sort);
				break;
			default:
				$this->db->order_by($sort_by,$sort);
				break;	
		}
		
		//$this->db->having("distance <= '".$this->distance."'");
		
		$this->db->group_by('tevent.feventid');
		
		$query = $this->db->get('tevent');
		return $query->num_rows();
	}
	
	public function get_country($offset,$count=false){
		$this->limit = 30;
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		$this->db->order_by('fcountryname','ASC');
		if($offset!==FALSE) 
			$query = $this->db->get('tcountry', $this->limit, $offset);
		else
			$query = $this->db->get('tcountry');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}
	
	public function get_country_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		
		$query = $this->db->get('tcountry');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}
	
	public function get_province($offset,$count=false){
		$this->limit = 30;
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		$this->db->where('fcountrycode',$this->countryCode);
		$this->db->order_by('fprovincename','ASC');
		if($offset!==FALSE) 
			$query = $this->db->get('tprovince', $this->limit, $offset);
		else
			$query = $this->db->get('tprovince');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}
	
	public function get_province_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		$this->db->order_by('fprovincename','ASC');
			$query = $this->db->get('tprovince');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}
	
	public function get_city($province=6,$offset,$count=false){
		if(!empty($this->input->post('province_id',TRUE))) $province = $this->input->post('province_id',TRUE);
		$this->limit = 30;
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		$this->db->where('fprovinceid',$province);
		$this->db->order_by('fcityname','ASC');
		if($offset!==FALSE) 
			$query = $this->db->get('tcity', $this->limit, $offset);
		else
			$query = $this->db->get('tcity');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}
	
	public function get_tickets(){
		$this->db->select('*');	
		$this->db->where('feventid',$this->input->post('event_id',TRUE));
		$this->db->where('fticketstock >= 1');
		if(!empty($this->input->post('schedule',TRUE)))
			$this->db->where('fscheduleid',$this->input->post('schedule',TRUE));
		$query = $this->db->get('tticket');
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	
	public function get_ticket_where($where,$single=true){
		$this->db->select('*');	
		$this->db->where($where);
		$query = $this->db->get('tticket');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();	
			else
				return $query->result_array();	
		}
	}
	
	public function get_claimed($where,$count=false){		
		$this->db->select('*');	
		$this->db->where($where);
		$query = $this->db->get('tclaimedticket');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $query->num_rows();
		}
	}
	
	public function get_activity($where,$count=false){		
		$this->db->select('*');	
		$this->db->where($where);
		$query = $this->db->get('tactivity');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $query->num_rows();
		}
	}
	
	public function get_review($offset,$count=false){
		$this->limit = 30;
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort = ($this->input->post('sort',TRUE)) ? $this->input->post('sort',TRUE) : 'DESC';
		$this->db->select('freviewid,freviewtext,freviewrating,freviewdate,treview.fuserid,fuserfullname,fuserbirthdate,fuseremail,fuserprofpic,feventrating,fuserparentid,fuserstatus,feventrating');
		$this->db->join('tusers', 'tusers.fuserid = treview.fuserid');
		$this->db->join('tevent', 'tevent.feventid = treview.feventid');
		$this->db->where('treview.feventid',$this->input->post('event_id',TRUE));
		$this->db->where('freviewstatus',1);
		$this->db->order_by('freviewdate',$sort);
		if($offset!==FALSE) 
			$query = $this->db->get('treview', $this->limit, $offset);
		else
			$query = $this->db->get('treview');
			
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $query->num_rows();
		}	
	}
	
	public function get_review_where($where,$count=false){		
		$this->db->select('*');	
		$this->db->where($where);
		$this->db->where('freviewstatus',1);
		$this->db->join('tusers', 'tusers.fuserid = treview.fuserid');
		$this->db->join('tevent', 'tevent.feventid = treview.feventid');
		$query = $this->db->get('treview');
		
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			elseif($count=='single')
				return $query->row_array();
			else
				return $query->num_rows();
		}
	}
	
	public function event_dashboard($where,$field='count(feventid) as totalevent'){
		$this->db->select($field);	  
		$this->db->where($where);
		$query = $this->db->get('tevent');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			return $query->row_array();	
		}
	}
}
?>