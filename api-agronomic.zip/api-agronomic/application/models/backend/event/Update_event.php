<?php class Update_event extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function updateEvent($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tevent');
//		echo $this->db->last_query();
		return true;
	}
	
	public function updateEventMeta($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('teventmeta');
		return $result;
	}
	
	public function updateReview($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('treview');
		return $result;
	}
	
	public function updateTicket($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tticket');
		return $result;
	}
}
?>