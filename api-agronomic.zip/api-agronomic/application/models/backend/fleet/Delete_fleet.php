<?php class Delete_fleet extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteFleet($fleet){
		$this->db->where($fleet);
		$this->db->delete('tfleet'); 
	}
   
	/*public function deleteFleetMeta($meta){
		$this->db->where($meta);
		$this->db->delete('tfleetmeta'); 
	}*/
   
}
?>