<?php class Insert_fleet extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
  public function addNewFleet($fleet){
	  $this->db->set($fleet);
	  $this->db->insert('tfleet');
	  return $this->db->insert_id();
  }

  /*public function addFleetMeta($insert){
	  $this->db->set($insert);
	  $this->db->insert('tfleetmeta');
	  return $this->db->insert_id();
  }*/
  
}
?>