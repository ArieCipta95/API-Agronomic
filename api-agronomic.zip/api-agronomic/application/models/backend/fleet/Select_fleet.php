<?php class Select_fleet extends CI_Model {
	
	var $limit = 20;
	var $order_by = 'tfleet.ffleetid';
	var $order = 'ASC';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get($offset = FALSE){
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = ($this->input->get_post('sort_by',TRUE)) ? $this->input->get_post('sort_by',TRUE) : $this->order_by;
		switch($sort_by){
			case 'vehiclename': $sort_by = 'fvehiclename';break;
			case 'fleetname': $sort_by = 'ffleetname';break;
			case 'status': $sort_by = 'ffleetstatus';break;
			default: $sort_by = $this->order_by;break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		$curStatus = $this->input->get_post('status',true);
		
		$this->db->select('*, count(ffleetid) as ffleettotal');	
		
		$this->db->join('tvehicle', 'tvehicle.fvehicleid = tfleet.fvehicleid');

		if(!empty($curStatus) && $curStatus!='') $this->db->where('ffleetstatus',$curStatus);
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'tfleet.ffleetid like '.$this->db->escape('%'.$keyword.'%').' OR tfleet.fvehicleid like '.$this->db->escape('%'.$keyword.'%').' OR tfleet.ffleetvehicleplatno like '.$this->db->escape('%'.$keyword.'%').' OR tvehicle.fvehiclename like '.$this->db->escape('%'.$keyword.'%').' OR ffleetname like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			
		}
		$whereFleet = 'tfleet.ffleetid != 0';
		$this->db->where($whereFleet); 
		$this->db->group_by('tfleet.ffleetid');
		$this->db->order_by($sort_by,$sort);
		
		if($offset!==FALSE) 
			$query = $this->db->get('tfleet', $this->limit, $offset);
		else
			$query = $this->db->get('tfleet');
			
		//uecho $this->db->last_query();
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}

	public function get_count()
	{		
		$this->db->select('*');
		$this->db->join('tvehicle', 'tvehicle.fvehicleid = tfleet.fvehicleid');
		$curStatus = $this->input->get_post('status',true);	
		if(!empty($curStatus) && $curStatus!='') $this->db->where('ffleetstatus',$curStatus);
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'tfleet.ffleetid like '.$this->db->escape('%'.$keyword.'%').' OR tfleet.fvehicleid like '.$this->db->escape('%'.$keyword.'%').' OR tfleet.ffleetvehicleplatno like '.$this->db->escape('%'.$keyword.'%').' OR tvehicle.fvehiclename like '.$this->db->escape('%'.$keyword.'%').' OR ffleetname like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			
		}
		$whereFleet = 'tfleet.ffleetid != 0';
		$this->db->where($whereFleet);
		$this->db->group_by('tfleet.ffleetid');
		$query = $this->db->get('tfleet');
		return $query->num_rows();
	}
	
	public function get_fleet_vehicle_where($where,$single=true){
		$this->db->select('*');
		$this->db->join('tvehicle', 'tvehicle.fvehicleid = tfleet.fvehicleid');
		$this->db->where($where);
		$this->db->where('fvehiclestatus != 0');
		$this->db->group_by('tfleet.fvehicleid');
		$query = $this->db->get('tfleet');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();	
			else
				return $query->result_array();	
		}
	}
	
	public function get_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		
		$query = $this->db->get('tfleet');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function get_meta_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$this->db->join('tvehicle', 'tvehicle.fvehicleid = tvehiclemeta.fvehicleid');
		$query = $this->db->get('tvehiclemeta');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function get_plate_no($where){
		$this->db->select('*');
		$this->db->where('fuservehicleid',$where);
		$query = $this->db->get('tuservehicle');
		return $query->row_array();
	}
	
	public function get_count_where($where='',$single=true){
		$this->db->select('count(distinct(tfleet.fvehicleid)) as total');	  
		$this->db->join('tvehicle', 'tvehicle.fvehicleid = tfleet.fvehicleid');
		if(!empty($where))$this->db->where($where);
		if(!empty($this->input->get_post('my',TRUE))){
			$this->db->where('DATE_FORMAT( FROM_UNIXTIME(  `forderdate` ),  "%m%y" ) = '.$this->input->get_post('my',TRUE));	
		}
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'tfleet.ffleetid like '.$this->db->escape('%'.$keyword.'%').' OR tfleet.fvehicleid like '.$this->db->escape('%'.$keyword.'%').' OR tfleet.ffleetvehicleplatno like '.$this->db->escape('%'.$keyword.'%').' OR tvehicle.fvehiclename like '.$this->db->escape('%'.$keyword.'%').' OR ffleetname like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			
		}
		
		$query = $this->db->get('tfleet');
		//echo $this->db->last_query();
		return $query->row_array();
	}
	
	public function fleet_get_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$query = $this->db->get('tfleet');
		
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function get_fleet_vehicle(){
		$text = '';
		switch($status){
			case 1:$text = 'Active';break;
			case 2:$text = 'Featured';break;
			case 3:$text = 'Not Active';break;
			default:$text = 'All';break;
		}
		return $text;
	}
	
	public function fleet_status($status){
		$text = '';
		switch($status){
			case 1:$text = 'Active';break;
			case 2:$text = 'Featured';break;
			case 3:$text = 'Not Active';break;
			default:$text = 'All';break;
		}
		return $text;
	}
	
	public function fleet_dashboard($time='-30 days',$field='sum(fordertotalprice) as totalsales',$status=array(3)){
		$this->db->select($field);	  
		$this->db->where('DATE_FORMAT(FROM_UNIXTIME(  `forderdate` ), "%m%Y" ) = '.$time);
		$this->db->where_in('ffleetstatus',$status);
		$query = $this->db->get('tfleet');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			return $query->row_array();	
		}
	}


}
?>