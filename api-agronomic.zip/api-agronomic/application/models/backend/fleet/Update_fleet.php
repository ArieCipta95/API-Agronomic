<?php class Update_fleet extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function updateFleet($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tfleet');
//		echo $this->db->last_query();
		return true;
	}
	
	public function updateFleetMeta($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tfleetmeta');
//		echo $this->db->last_query();
		return $result;
	}
}
?>