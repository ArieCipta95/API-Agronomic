<?php class Insert_media extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
  
	public function addNewMedia($insert){
		 $this->db->set($insert);
		 $this->db->insert('tmedia');
		 return $this->db->insert_id();
	}
}
?>