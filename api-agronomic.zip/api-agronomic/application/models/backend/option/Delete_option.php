<?php class Delete_option extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteSetting($table,$where){
		$this->db->where($where);
		$this->db->delete($table); 
	}
}
?>