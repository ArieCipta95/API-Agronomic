<?php class Select_option extends CI_Model {

	var $limit = 20;
	var $order_by = 'fbrandname';
	var $order = 'ASC';

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get_option($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		$query = $this->db->get('toption');
		
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
 
	public function get_brand($offset,$count=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		/*$sort_by = $this->input->get_post('sort_by',TRUE);
		switch($sort_by){
			case 'id': $sort_by = 'fbrandid';break;
			case 'id': $sort_by = 'fbrandid';break;
			case 'number': $sort_by = 'fbrandnumber';break;
			case 'status': $sort_by = 'fbrandstatus';break;
			default: $sort_by = 'fbrandname';break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		*/
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fbrandid like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		if($offset!==FALSE) 
			$query = $this->db->get('tbrand', $this->limit, $offset);
		else
			$query = $this->db->get('tbrand');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}

	public function get_service($offset,$count=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		/*$sort_by = $this->input->get_post('sort_by',TRUE);
		switch($sort_by){
			case 'id': $sort_by = 'fserviceid';break;
			case 'id': $sort_by = 'fserviceid';break;
			case 'number': $sort_by = 'fservicenumber';break;
			case 'status': $sort_by = 'fservicestatus';break;
			default: $sort_by = 'fservicename';break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		*/
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fservicename like '.$this->db->escape('%'.$keyword.'%').' OR fserviceid like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		if($offset!==FALSE) 
			$query = $this->db->get('tservice', $this->limit, $offset);
		else
			$query = $this->db->get('tservice');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}

	public function get_subservice($offset,$count=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		if($offset!==FALSE) 
			$query = $this->db->get('tsubservice', $this->limit, $offset);
		else
			$query = $this->db->get('tsubservice');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}

	public function get_fleet($offset,$count=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		$this->db->where('ffleetid != 0');
		if($offset!==FALSE) 
			$query = $this->db->get('tfleet', $this->limit, $offset);
		else
			$query = $this->db->get('tfleet');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}

	public function get_slider($offset,$count=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		if($offset!==FALSE) 
			$query = $this->db->get('tslider', $this->limit, $offset);
		else
			$query = $this->db->get('tslider');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}

	public function get_crew($offset,$count=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		if($offset!==FALSE) 
			$query = $this->db->get('tcrew', $this->limit, $offset);
		else
			$query = $this->db->get('tcrew');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}

	public function get_fleet_where($where,$single=true){
		$this->db->select('*');
		$this->db->where('ffleetid != 0');
		$this->db->where($where);
		
		$query = $this->db->get('tfleet');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}
	

	public function test($orders) {
		if(!empty($orders)) {
			foreach ($orders as $order) {
				$where['forderid'] = $order['forderid'];
				$result = $this->testlagi($where);
				/*echo '<pre>';
				print_r($result);
				echo '<pre>';*/
				$order['cart'] = $result;

			}
		}
		return $orders;
	}

	public function getAvaibleFleet($date,$hour) {
        $this->db->select('*');
        $this->db->join('thour','tclaimedservice.fhourid = thour.fhourid');
        $this->db->join('tcart','tclaimedservice.fcartid = tcart.fcartid');
        $this->db->where('tcart.fbookingdate', $date);
        $this->db->where('fexpireddate > UNIX_TIMESTAMP(NOW())');
        //$this->db->where("$date['fcheckdate'] BETWEEN DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND CURDATE()");
        $query = $this->db->get('tclaimedservice');
        //if ($query->num_rows() > 0){          
            //if($single)
                //return $query->row_array();
            //else
                return $query->result_array();
    }

	public function testlagi($where) {
		$this->db->select('*');
		$this->db->where($where);
		$this->db->join('tcarthour','tcarthour.fcartid = tcart.fcartid');
		$query = $this->db->get('tcart');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}
		return 0;	
	}

	public function get_year_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		
		$query = $this->db->get('tvehiclemeta');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}

	public function get_brand_count(){
		$this->db->select('*');
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fbrandid like '.$this->db->escape('%'.$keyword.'%').' OR fbrandnumber like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		$query = $this->db->get('tbrand');
		return $query->num_rows();	
	}
	
	public function get_brand_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		
		$query = $this->db->get('tbrand');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}
	
	public function get_vehicle($offset,$count=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');		
		$this->db->join('tbrand','tbrand.fbrandid = tvehicle.fbrandid');
		$sort_by = $this->input->get_post('sort_by',TRUE);
		
		switch($sort_by){
			case 'id': $sort_by = 'fvehicleid';break;
			case 'brand': $sort_by = 'fbrandname';break;
			case 'platno': $sort_by = 'fvehicleplatno';break;
			case 'status': $sort_by = 'fvehiclestatus';break;
			case 'name': $sort_by = 'fvehiclename';break;
			default: $sort_by = 'default';break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fvehiclename like '.$this->db->escape('%'.$keyword.'%').' OR fvehicleplatno like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		if($sort_by!='default')
			$this->db->order_by($sort_by,$sort);
		else
			$this->db->order_by('fbrandname ASC, fvehiclename ASC');
		if($offset!==FALSE) 
			$query = $this->db->get('tvehicle', $this->limit, $offset);
		else
			$query = $this->db->get('tvehicle');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}

	public function get_data_vehicle($where,$single=true){
		$this->db->select('*');
		$this->db->where('fuservehicleid',$where);
		$this->db->join('tvehicle','tvehicle.fvehicleid=tuservehicle.fvehicleid');
		$this->db->join('tbrand','tbrand.fbrandid=tvehicle.fbrandid');

		$query = $this->db->get('tuservehicle');
		//if ($query->num_rows() > 0){
			// if(!$single)
			// 	return $query->result_array();
			// else
				return $query->row_array();
		//}
	}
	
	public function get_vehicle_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		
		$query = $this->db->get('tvehicle');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}

	public function get_user_vehicle_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		
		$query = $this->db->get('tuservehicle');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}
	
	public function get_vehicle_count(){
		$this->db->select('*');
		
		
		$this->db->join('tbrand','tbrand.fbrandid = tvehicle.fbrandid');
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fvehiclename like '.$this->db->escape('%'.$keyword.'%').' OR fvehicleplatno like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		$query = $this->db->get('tvehicle');
		return $query->num_rows();	
	}

	public function get_user_vehicle_id_where($where,$single=false){
		//$this->db->limit(2);  
		$this->db->select('*');
		$this->db->where('fuserid',$where);
		// $this->db->where('fvehicleid',$vehicleID);
		$this->db->order_by('fuservehicleid', 'desc');
		//$this->db->group_by('fuservehicleid');

		$query = $this->db->get('tuservehicle');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}
		
	}
	
	public function get_city($offset,$count=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		$this->db->join('tvehicle','tvehicle.fvehicleid = tcity.fvehicleid');
		$this->db->join('tbrand','tbrand.fbrandid = tvehicle.fbrandid');
		$sort_by = $this->input->get_post('sort_by',TRUE);
		
		switch($sort_by){
			case 'id': $sort_by = 'fcityid';break;
			case 'brand': $sort_by = 'fbrandname';break;
			case 'vehicle': $sort_by = 'fvehiclename';break;
			case 'status': $sort_by = 'fcitystatus';break;
			case 'name': $sort_by = 'fcityname';break;
			default: $sort_by = 'default';break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fvehiclename like '.$this->db->escape('%'.$keyword.'%').' OR fcityname like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		if($sort_by!='default')
			$this->db->order_by($sort_by,$sort);
		else
			$this->db->order_by('fbrandname ASC, fvehiclename ASC, fcityname ASC');
		if($offset!==FALSE) 
			$query = $this->db->get('tcity', $this->limit, $offset);
		else
			$query = $this->db->get('tcity');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}
	
	public function get_city_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		
		$query = $this->db->get('tcity');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}
	
	public function get_city_count(){
		$this->db->select('*');		
		$this->db->join('tvehicle','tvehicle.fvehicleid = tcity.fvehicleid');
		$this->db->join('tbrand','tbrand.fbrandid = tvehicle.fbrandid');
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fbrandname like '.$this->db->escape('%'.$keyword.'%').' OR fvehiclename like '.$this->db->escape('%'.$keyword.'%').' OR fcityname like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		$query = $this->db->get('tcity');
		return $query->num_rows();	
	}
	
	public function get_category($offset,$count=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		
		$sort_by = $this->input->get_post('sort_by',TRUE);
		
		switch($sort_by){
			case 'id': $sort_by = 'fcategoryid';break;
			case 'description': $sort_by = 'fcategorydesc';break;
			case 'order': $sort_by = 'fcategoryorder';break;
			case 'status': $sort_by = 'fcategorystatus';break;
			case 'name': $sort_by = 'fcategoryname';break;
			default: $sort_by = 'fcategoryorder';break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fcategoryname like '.$this->db->escape('%'.$keyword.'%').' OR fcategorydesc like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		$this->db->order_by($sort_by,$sort);
		if($offset!==FALSE) 
			$query = $this->db->get('tcategory', $this->limit, $offset);
		else
			$query = $this->db->get('tcategory');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}
	
	public function get_category_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		
		$query = $this->db->get('tcategory');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}
	
	public function get_category_count(){
		$this->db->select('*');	
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fcategoryname like '.$this->db->escape('%'.$keyword.'%').' OR fcategorydesc like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		$query = $this->db->get('tcategory');
		return $query->num_rows();	
	}
	
	public function get_interest($offset,$count=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');
		
		$sort_by = $this->input->get_post('sort_by',TRUE);
		
		switch($sort_by){
			case 'id': $sort_by = 'finterestid';break;
			case 'description': $sort_by = 'finterestdesc';break;
			case 'status': $sort_by = 'fintereststatus';break;
			case 'name': $sort_by = 'finterestname';break;
			default: $sort_by = 'finterestid';break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'finterestname like '.$this->db->escape('%'.$keyword.'%').' OR finterestdesc like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		$this->db->order_by($sort_by,$sort);
		if($offset!==FALSE) 
			$query = $this->db->get('tinterest', $this->limit, $offset);
		else
			$query = $this->db->get('tinterest');
		if ($query->num_rows() > 0){
			if(!$count)
				return $query->result_array();
			else
				return $this->db->count_all_results();
		}	
	}
	
	public function get_interest_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		
		$query = $this->db->get('tinterest');
		if ($query->num_rows() > 0){
			if(!$single)
				return $query->result_array();
			else
				return $query->row_array();
		}	
	}
	
	public function get_interest_count(){
		$this->db->select('*');	
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'finterestname like '.$this->db->escape('%'.$keyword.'%').' OR finterestdesc like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		$query = $this->db->get('tinterest');
		return $query->num_rows();	
	}
}
?>