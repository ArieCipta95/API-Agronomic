<?php class Update_option extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function updateOption($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('toption');
		return $result;
	}
	
	public function updateBrand($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tbrand');
		return $result;
	}
	
	public function updateProvince($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tprovince');
		return $result;
	}
	
	public function updateCity($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tcity');
		return $result;
	}
	
	public function updateCategory($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tcategory');
		return $result;
	}
	
	public function updateInterest($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tinterest');
		return $result;
	}
	
	public function updateBatch($table='',$updates=array(),$in=''){
		$result = $this->db->update_batch($table,$updates,$in);	
		return $result;
	}
}
?>