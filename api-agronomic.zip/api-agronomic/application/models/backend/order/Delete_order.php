<?php class Delete_order extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteOrder($where){
		$this->db->where($where);
		$this->db->delete('torder'); 
	}
   
	public function deleteContact($where){
		$this->db->where($where);
		$this->db->delete('tordercontact'); 
	}
   
	public function deleteClaim($where){
		$this->db->where($where);
		$this->db->delete('tclaimedservice'); 
	}
   
	public function deleteCart($where){
		$this->db->where($where);
		$this->db->delete('tcart'); 
	}
   
	public function deleteActivity($where){
		$this->db->where($where);
		$this->db->delete('tactivity'); 
	}
}
?>