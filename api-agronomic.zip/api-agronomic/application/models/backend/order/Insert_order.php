<?php class Insert_order extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function claimOrder($insert){
		$insert['flastactivity'] = time();
		$insert['fexpireddate'] = ($insert['flastactivity'] + $insert['fexpireddate']);
		$this->db->replace('tclaimedticket', $insert);
		return true;
	}
	
	public function createOrder($insert){
		$this->db->insert('torder', $insert);
		return $this->db->insert_id();
	}

	public function createLog($insert){
		$this->db->insert('tlogdevice',$insert);
		return $this->db->insert_id();
	}
	
	public function createCart($insert){
		$insert['ftickettimestamp'] = time();
		$this->db->insert('tcart', $insert);
		return $this->db->insert_id();
	}
	
	public function createContact($insert){
		$this->db->insert('tordercontact', $insert);
		return $this->db->insert_id();
	}
  
	  public function createActivity($insert){
		  $this->db->set($insert);
		  $this->db->insert('tactivity');
		  return $this->db->insert_id();
	  }
	  
}
?>