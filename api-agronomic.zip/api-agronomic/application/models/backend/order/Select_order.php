<?php class Select_order extends CI_Model {
	
	var $limit = 20;
	var $order_by = 'torder.forderid';
	var $order = 'DESC';
	
	public function __construct()
	{
		parent::__construct(); 
		$this->load->database();
	}
	
	public function get($offset = FALSE){
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = ($this->input->get_post('sort_by',TRUE)) ? $this->input->get_post('sort_by',TRUE) : $this->order_by;
		switch($sort_by){
			case 'date':$sort_by ='fbookingdate';break;
			case 'hour':$sort_by ='fstarthour';break;
			case 'customer': $sort_by = 'fuserfirstname';break;
			case 'amount': $sort_by = 'fordertotalprice';break;
			case 'status': $sort_by = 'forderprocessed';break;
			default: $sort_by = $this->order_by;break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		$curStatus = $this->input->get_post('status',true);
		$mydate = $this->input->get_post('my',TRUE);
		
		$this->db->select('*, count(fcartid) as fordertotalitem');

		$this->db->join('tcart', 'tcart.forderid = torder.forderid');
		$this->db->join('tusers', 'tusers.fuserid = torder.fuserid');
		if(!empty($mydate)){

			switch ($mydate) {
				case 'Tomorrow':$dodate = "fbookingdate > curdate()";break;
				case 'Last Days':$dodate = "fbookingdate < curdate()";break;
				default:
					$dodate = "fbookingdate = curdate()";
					break;
			}
			$this->db->where($dodate);
		}
		if(!empty($curStatus) && $curStatus!='') $this->db->where('forderprocessed',$curStatus);
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'torder.forderid like '.$this->db->escape('%'.$keyword.'%').' OR torder.fuserid like '.$this->db->escape('%'.$keyword.'%').' OR fuserfirstname like '.$this->db->escape('%'.$keyword.'%').'OR fuserlastname like '.$this->db->escape('%'.$keyword.'%').' OR fuserphone like '.$this->db->escape('%'.$keyword.'%').' OR fuseremail like '.$this->db->escape('%'.$keyword.'%').' OR fuserphone like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		$this->db->group_by('torder.forderid');
		$this->db->order_by($sort_by,$sort);
		
		if($offset!==FALSE) 
			$query = $this->db->get('torder', $this->limit, $offset);
		else
			$query = $this->db->get('torder');
			
		// echo $this->db->last_query();
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}

	public function get_data_service_where($where,$single=TRUE){
		$this->db->select('forderdataservice');
		$this->db->where($where);
		$query = $this->db->get('torder');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();	
			else
				return $query->result_array();	
		}
	}
	
	public function get_filter($offset = FALSE){

		if($offset) $offset = ($offset-1)*$this->limit;
		$this->db->select('case when fbookingdate = curdate() then "Today"
			when fbookingdate >= curdate() then "Tomorrow"
			when fbookingdate <= curdate() then "Last Days" end as my');

		
		$this->db->join('tcart', 'tcart.forderid = torder.forderid');
		$this->db->join('tusers', 'tusers.fuserid = torder.fuserid');
		
		
		if(!empty($curStatus) && $curStatus!='') $this->db->where('forderprocessed',$curStatus);
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'torder.forderid like '.$this->db->escape('%'.$keyword.'%').' OR torder.fuserid like '.$this->db->escape('%'.$keyword.'%').' OR fuserfirstname like '.$this->db->escape('%'.$keyword.'%').'OR fuserlastname like '.$this->db->escape('%'.$keyword.'%').' OR fuserphone like '.$this->db->escape('%'.$keyword.'%').' OR fuseremail like '.$this->db->escape('%'.$keyword.'%').' OR fuserphone like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		$this->db->group_by('my');
		$this->db->order_by('forderdate','desc');
		
		$query = $this->db->get('torder');
			
		//echo $this->db->last_query();
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}

	public function get_count()
	{		
		$this->db->select('*');

		$this->db->join('tcart', 'tcart.forderid = torder.forderid');
		$this->db->join('tusers', 'tusers.fuserid = torder.fuserid');
		$curStatus = $this->input->get_post('status',true);
		
		if(!empty($curStatus) && $curStatus!='') $this->db->where('forderprocessed',$curStatus);
		if(!empty($this->input->get_post('my',TRUE))){
			if($this->input->get_post('my',TRUE) == "Today"){
				$dodate = "fbookingdate = curdate()";
			}else if($this->input->get_post('my',TRUE) == "Tomorrow"){
				$dodate = "fbookingdate > curdate()";
			}else if($this->input->get_post('my',TRUE) == "Last Days")
				$dodate = "fbookingdate < curdate()";
			$this->db->where($dodate);
		}
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'torder.forderid like '.$this->db->escape('%'.$keyword.'%').' OR torder.fuserid like '.$this->db->escape('%'.$keyword.'%').' OR fuserfirstname like '.$this->db->escape('%'.$keyword.'%').'OR fuserlastname like '.$this->db->escape('%'.$keyword.'%').' OR fuserphone like '.$this->db->escape('%'.$keyword.'%').' OR fuseremail like '.$this->db->escape('%'.$keyword.'%').' OR fuserphone like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		//echo $this->db->last_query();
		$this->db->group_by('torder.forderid');
		$query = $this->db->get('torder');
		return $query->num_rows();
	}
	
	public function get_fleet_stock(){
        $this->db->select('*');
        $query = $this->db->get('tfleet');
        return $query->num_rows();
    }

    public function get_hour(){
        $this->db->select('*');
        $query = $this->db->get('thour');
        return $query->num_rows();
    }

    public function get_hourid(){
    	$this->db->select('*');
    	$query = $this->db->get('thour'); 
    	return $query->result_array();
    }

    public function getAvaibleFleet($date,$hour) {
        $this->db->select('*');
        $this->db->join('thour','tclaimedservice.fhourid = thour.fhourid');
        $this->db->join('tcart','tclaimedservice.fcartid = tcart.fcartid');
        $this->db->where('tcart.fbookingdate', $date);
        $this->db->where('fexpireddate > UNIX_TIMESTAMP(NOW())');
        //$this->db->where("$date['fcheckdate'] BETWEEN DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND CURDATE()");
        $query = $this->db->get('tclaimedservice');
        //if ($query->num_rows() > 0){          
            //if($single)
                //return $query->row_array();
            //else
                return $query->result_array();
    }


	public function get_order_contact_where($where,$single=true){
		$this->db->select('*, UNIX_TIMESTAMP() as "skrg",(forderexpired-UNIX_TIMESTAMP()) as "waktu"');
		$this->db->join('torder', 'torder.forderid = tcart.forderid');
		$this->db->join('tusers', 'tusers.fuserid = tcart.fuserid');
		$this->db->where($where);
		$this->db->group_by('torder.forderid');
		$query = $this->db->get('tcart');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();	
			else
				return $query->result_array();	
		}
	}
	
	public function get_vehicle_service_where($where,$single=true){
		$this->db->select('*');
		$this->db->join('tvehicle', 'vehicle.fvehicleid = torder.fuserid');
		$this->db->where($where);
		$query = $this->db->get('tservice');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();	
			else
				return $query->result_array();	
		}
	}

	public function get_contacts_where($where,$single=true){ 
		$this->db->select('*');	  
		$this->db->where($where);
		//$this->db->join('tordercontact', 'tordercontact.forderid = torder.forderid');
		$query = $this->db->get('torder');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_crew_device_where($where,$single=true){ 
		$this->db->select('fdeviceinstanceid');
		$this->db->where('fis_crew = 1');	  
		$this->db->where($where);
		$this->db->join('tfleet', 'tfleet.fcrewid = tdevice.fuserid');
		$query = $this->db->get('tdevice');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function get_fleet_crew($where,$single=false){
		$this->db->select('fdeviceinstanceid as registration_ids');
		$this->db->where('fis_crew = 1');	 
		$this->db->where($where);
		$this->db->join('tcart', 'tcart.forderid = torder.forderid');
		$this->db->join('tcrew', 'tcrew.ffleetid = tcart.ffleetid');
		$this->db->join('tdevice', 'tdevice.fuserid = tcrew.fcrewid');
		$query = $this->db->get('torder');
		if ($query->num_rows()>0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	/*public function get_fleet_where($where,$single=false){
		$this->db->select('*');	 
		$this->db->where($where);
		$this->db->join('torder', 'torder.ffleetid = tfleet.ffleetid');
		$query = $this->db->get('tfleet');
		if ($query->num_rows()>0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}*/

	public function get_order_cart_where($where){ 
		$this->db->select('*');	  
		$this->db->join('torder', 'torder.forderid = tcart.forderid');
		$this->db->join('tclaimedservice', 'tclaimedservice.fuserid = tcart.fuserid');
		$this->db->where($where);
		//$this->db->join('tordercontact', 'tordercontact.forderid = torder.forderid');
		$query = $this->db->get('tcart');
		//echo $this->db->last_query();
		//if ($query->num_rows() > 0){			
		//	if($single)
				return $query->row_array();
		//	else
		//		return $query->result_array();
		//}
	}

	public function get_claimed_service_where($where,$single=true){ 
		$this->db->select('*');	  
		$this->db->join('torder', 'torder.fuserid = tclaimedservice.fuserid');
		$this->db->where($where);
		//$this->db->join('tordercontact', 'tordercontact.forderid = torder.forderid');
		$query = $this->db->get('tclaimedservice');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function get_claimed_where($where,$single=true,$exp=true){
		$this->db->select('*');	  
		$this->db->where($where);
		if($exp) $this->db->where('fexpireddate > UNIX_TIMESTAMP(NOW())');
		$query = $this->db->get('tclaimedservice');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}

	public function getClaimedSchedule($date) {
        $this->db->select('*');
        $this->db->join('thour','tclaimedservice.fhourid = thour.fhourid');
        $this->db->join('tcart','tclaimedservice.fcartid = tcart.fcartid');
        $this->db->where('tcart.fbookingdate', $date);
        $this->db->where('fexpireddate > UNIX_TIMESTAMP(NOW())');
        //$this->db->where("$date['fcheckdate'] BETWEEN DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND CURDATE()");
        $query = $this->db->get('tclaimedservice');
        //if ($query->num_rows() > 0){          
            //if($single)
                //return $query->row_array();
            //else
                return $query->result_array();
    }

	public function get_service_where($where,$single=true){
		$this->db->select('*');
		$this->db->join('tservice', 'tservice.fserviceid = tsubservice.fserviceid');
		$this->db->where($where);
		$query = $this->db->get('tsubservice');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_cart_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$query = $this->db->get('tcart');
//	echo $this->db->last_query();
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_where($where,$single=true){
		$this->db->select('*');
		$this->db->join('tcart', 'tcart.forderid = torder.forderid');
		$this->db->join('tusers', 'tusers.fuserid = torder.fuserid');	  
		$this->db->where($where);
		
		$query = $this->db->get('torder');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_count_where($where='',$single=true){
		$this->db->select('count(distinct(torder.forderid)) as total');	  
		
		$this->db->join('tcart', 'tcart.forderid = torder.forderid');
		$this->db->join('tusers', 'tusers.fuserid = torder.fuserid');
		
		if(!empty($where))$this->db->where($where);
		if(!empty($this->input->get_post('my',TRUE))){
			if($this->input->get_post('my',TRUE) == "Today"){
				$dodate = "fbookingdate = curdate()";
			}else if($this->input->get_post('my',TRUE) == "Tomorrow"){
				$dodate = "fbookingdate > curdate()";
			}else if($this->input->get_post('my',TRUE) == "Last Days")
				$dodate = "fbookingdate < curdate()";
			$this->db->where($dodate);
		}
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'torder.forderid like '.$this->db->escape('%'.$keyword.'%').' OR torder.fuserid like '.$this->db->escape('%'.$keyword.'%').' OR fuserfirstname like '.$this->db->escape('%'.$keyword.'%').'OR fuserlastname like '.$this->db->escape('%'.$keyword.'%').' OR fuserphone like '.$this->db->escape('%'.$keyword.'%').' OR fuseremail like '.$this->db->escape('%'.$keyword.'%').' OR fuserphone like '.$this->db->escape('%'.$keyword.'%');
			if(!empty($curStatus)){
				$searchwhere = '('.$searchwhere.')';
			}
			$this->db->where($searchwhere);	
		}
		
		$query = $this->db->get('torder');
		//echo $this->db->last_query();
		return $query->row_array();
	}
	
	public function order_get_where($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		$query = $this->db->get('torder');
		
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function order_option($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$this->db->where_in('foptionstatus',1);
		$query = $this->db->get('toption');
		
		if ($query->num_rows() > 0){
			if($single){
				$row = $query->row_array();
				return $row['foptionvalue'];
			}else
				return $query->result_array();
		}
	}
	
	public function order_status($status){
		$text = '';
		switch($status){
			case 6:$text = 'complete';break;
			case 5:$text = 'cleaning';break;
			case 4:$text = 'arriving';break;
			case 3:$text = 'ontheway';break;
			case 2:$text = 'matching crew';break;
			default:$text = 'incomplete';break;
		}
		return $text;
	}
	
	public function order_dashboard($time='-30 days',$field='sum(fordertotalprice) as totalsales',$status=array(6)){
		$this->db->select($field);	  
		$this->db->where('DATE_FORMAT(FROM_UNIXTIME(  `forderdate` ), "%m%Y" ) = '.$time);
		$this->db->where_in('forderprocessed',$status);
		$query = $this->db->get('torder');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			return $query->row_array();	
		}
	}

	public function get_data_user_vehicle($where,$single=true){
		$this->db->select('*');
		$this->db->where($where);
		$query = $this->db->get('tuservehicle');
		if ($query->num_rows() > 0){
			if($single){
				$row = $query->row_array();
				return $row['foptionvalue'];
			}else
				return $query->result_array();
		}
	}

	public function get_user_vehicle_data($where){
		$this->db->select('*');
		$this->db->where('fuservehicleid',$where);
		$query = $this->db->get('tuservehicle');
		
			return $query->row_array();
	}
}
?>