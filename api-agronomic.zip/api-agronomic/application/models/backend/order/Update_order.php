<?php class Update_order extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function updateClaimOrder($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tclaimedticket');
		return $result;
	} 
	
	public function updateOrder($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('torder');
		return $result;
	}
	
	public function updateCartfleet($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tcart');
		return $result;
	}

	public function updateClaimfleet($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tclaimedservice');
		return $result;
	}
	
	public function updateCart($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tcart');
		return $result;
	}
	
	public function updateTicket($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tticket');
		return $result;
	}
	
	public function updateActivity($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tactivity');
		return $result;
	}
}
?>