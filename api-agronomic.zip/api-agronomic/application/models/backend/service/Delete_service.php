<?php class Delete_service extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteService($service,$delete){
		$this->db->where($service);
		$this->db->delete($delete); 
	}
}
?>