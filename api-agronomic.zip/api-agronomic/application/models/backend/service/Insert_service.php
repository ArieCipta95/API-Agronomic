<?php class Insert_service extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
  public function addService($service,$table){
	  $this->db->set($service);
	  $this->db->insert($table); 
	  return $this->db->insert_id();
  }
}
?>