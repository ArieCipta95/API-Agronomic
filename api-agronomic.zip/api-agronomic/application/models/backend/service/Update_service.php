<?php class Update_service extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function updateService($update,$where,$table){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update($table);
//		echo $this->db->last_query();
		return true;
	}
}
?>