<?php class Delete_slider extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteSlider($slider){
		$this->db->where($slider);
		$this->db->delete('tslider'); 
	}
   
	public function deleteSliderMeta($meta){
		$this->db->where($meta);
		$this->db->delete('tslidermeta'); 
	}
   
}
?>