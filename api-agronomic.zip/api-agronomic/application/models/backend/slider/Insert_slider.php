<?php class Insert_slider extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
  public function addNewSlider($slider){
	  $this->db->set($slider);
	  $this->db->insert('tslider');
	  return $this->db->insert_id();
  }
	
}
?>