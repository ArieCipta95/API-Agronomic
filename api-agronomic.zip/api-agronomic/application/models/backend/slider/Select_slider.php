<?php class Select_slider extends CI_Model {

	var $limit = 20;
	var $order_by = 'fsliderid';
	var $order = 'ASC';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function get($offset = FALSE){
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = ($this->input->get_post('sort_by',TRUE)) ? $this->input->get_post('sort_by',TRUE) : $this->order_by;
		switch($sort_by){
			case 'id': $sort_by = 'fsliderid';break;
			case 'name': $sort_by = 'fimageheader';break;
			case 'status': $sort_by = 'fsliderstatus';break;
			default: $sort_by = $this->order_by;break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		
		$this->db->select('*');
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fimageheader like '.$this->db->escape('%'.$keyword.'%').' OR fimagedesc like '.$this->db->escape('%'.$keyword.'%').' OR fimageheader like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		$this->db->order_by($sort_by,$sort);
		
		if($offset!==FALSE) 
			$query = $this->db->get('tslider', $this->limit, $offset);
		else
			$query = $this->db->get('tslider');
		
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	
	public function get_where($where,$single=true){
		$this->db->select('*');
		
		$this->db->where($where);
		
		$query = $this->db->get('tslider');
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_count()
	{
		
		$this->db->select('*');
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fimageheader like '.$this->db->escape('%'.$keyword.'%').' OR fimagedesc like '.$this->db->escape('%'.$keyword.'%').' OR fimageheader like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		$query = $this->db->get('tslider');
		return $query->num_rows();
	}
}
?>