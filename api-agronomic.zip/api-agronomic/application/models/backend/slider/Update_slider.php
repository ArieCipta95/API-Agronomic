<?php class Update_slider extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function updateSlider($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tslider');
//		echo $this->db->last_query();
		return true;
	}
	
	public function updateSliderMeta($update,$where){
		$this->db->set($update);
		$this->db->where($where);
		$result = $this->db->update('tslidermeta');
		return $result;
	}
}
?>