<?php class Delete_user extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteUser($where){
		$this->db->where($where);
		$this->db->delete('tusers'); 
	}
   
	public function deleteUserMeta($where){
		$this->db->where($where);
		$this->db->delete('tusersmeta'); 
	}
   
	public function deleteCoupon($where){
		$this->db->where($where);
		$this->db->delete('tcoupon'); 
	}
}
?>