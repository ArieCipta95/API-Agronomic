<?php class Select_user extends CI_Model {

	var $limit = 20;
	var $order_by = 'fuserfirstname';
	var $order = 'ASC';

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	 
	public function checkEmail($user){
		$this->db->from('tusers');  
		$this->db->where('fuseremail',$user['fuseremail']);
		$this->db->where_in('fuserstatus',array(0,1));
		return $this->db->count_all_results();
	}
	
	public function checkUsername($user){
		$this->db->from('tusers');  
		$this->db->where('fusername',$user['username']);
		$this->db->where_in('fuserstatus',array(0,1));
		return $this->db->count_all_results();
	}
	
	public function checkPass($user){
		$this->db->from('tusers');  
		$this->db->where('fuserid',$user['userID']);
		$this->db->where('fuserpassword',$user['currentPassword']);
		$this->db->where_in('fuserstatus',array(0,1));
		return $this->db->count_all_results();
	}
	
	public function checkLogin($user,$offset = FALSE){
		$this->limit = 1;
		$this->db->select('fuserid');
		$this->db->where($user);
		$query = $this->db->get('tusers');
		
		if ($query->num_rows() > 0){
			$data = $query->row_array();
			return $data['fuserid'];
		}
	}
	
	public function checkLoginSocmed($user,$offset = FALSE){
		$sql = "SELECT * FROM `tusersmeta` m1, `tusersmeta` m2, `tusersmeta` m3, `tusers` u
			WHERE m1.fuserid = m2.fuserid
			and m1.fuserid = m3.fuserid
			and m1.fmetakey = 'socmed_type'
			and m1.fmetavalue = ".$this->db->escape($user['socmed_type'])."
			and m2.fmetakey = 'socmed_id'
			and m2.fmetavalue = ".$this->db->escape($user['socmed_id'])."
			and m1.fuserid = u.fuserid
			LIMIT 1";
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0){
			return $query->row_array();
		}
	}
	
	
	//
	public function get($offset=1,$child=false){
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = $this->input->get_post('sort_by',TRUE);
		switch($sort_by){
			case 'first_name': $sort_by = 'fuserfirstname';break;
			case 'last_name': $sort_by = 'fuserlastname';break;
			case 'name': $sort_by = 'fuserfirstname';break;
			case 'birthdate': $sort_by = 'fuserbirthdate';break;
			case 'gender': $sort_by = 'fusergender';break;
			case 'app': $sort_by = 'fuserappver';break;
			case 'device': $sort_by = 'fuserdevice';break;
			case 'date': $sort_by = 'fuserregiserdate';break;
			case 'status': $sort_by = 'fuserstatus';break;
			default: $sort_by = 'fuserid';break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		$this->db->select('*');
		$curRole = $this->input->get_post('role',true);
		
			
		if(!empty($curRole) && $curRole!='') $this->db->where('froleid',$curRole);
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fuserfirstname like '.$this->db->escape('%'.$keyword.'%').' OR fuseremail like '.$this->db->escape('%'.$keyword.'%').' OR fuserdevice like '.$this->db->escape('%'.$keyword.'%').' OR fcountryname like '.$this->db->escape('%'.$keyword.'%').' OR fuserphone like '.$this->db->escape('%'.$keyword.'%');;
			$this->db->where($searchwhere);	
		}
		
		$this->db->order_by($sort_by,$sort);
		$this->db->group_by('tusers.fuserid');
			  
		if($offset!==FALSE)
			$query = $this->db->get('tusers', $this->limit, $offset);	
		else	
			$query = $this->db->get('tusers');
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	
	public function get_count($child=false){	
		$this->db->select('*');
		
		$curRole = $this->input->get_post('role',true);
		if(!empty($curRole) && $curRole!='') $this->db->where('froleid',$curRole);
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fuserfirstname like '.$this->db->escape('%'.$keyword.'%').' OR fuseremail like '.$this->db->escape('%'.$keyword.'%').' OR fuserdevice like '.$this->db->escape('%'.$keyword.'%').' OR fuserphone like '.$this->db->escape('%'.$keyword.'%');;
			$this->db->where($searchwhere);	
		}
		
		$this->db->group_by('tusers.fuserid');
		
		$query = $this->db->get('tusers');
		return $query->num_rows();
	}
	
	public function get_where($where,$single=true){
		$this->db->select('*');	  
		$this->db->where($where);
		$query = $this->db->get('tusers');
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_count_where($where='',$single=true,$child=false){
		$this->db->select('*');	  
		if(!empty($where))$this->db->where($where);
		
		$query = $this->db->get('tusers');
		return $query->num_rows();
	}
	
	public function get_meta_where($where,$single=true){
		$this->limit = 10;
		$offset = (int)$this->input->post('page',TRUE);
		if(!$offset) $offset = 1;
		if(!$single) $offset = ($offset-1)*$this->limit;
		$this->db->select('*');	  
		$this->db->where($where);
		$this->db->where_in('fuserstatus',array(0,1));
		$this->db->join('tusers', 'tusers.fuserid = tusersmeta.fuserid');
		if($single)
			$query = $this->db->get('tusersmeta');
		else
			$query = $this->db->get('tusersmeta', $this->limit, $offset);
		
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
  
	public function get_count_meta($meta){
		$this->db->from('tusersmeta');  
		$this->db->where($meta);	
		return $this->db->count_all_results();
	}
	
	public function get_coupons($offset=1){
		if($offset) $offset = ($offset-1)*$this->limit;
		$sort_by = $this->input->get_post('sort_by',TRUE);
		switch($sort_by){
			case 'name': $sort_by = 'fcouponcode';break;
			case 'value': $sort_by = 'fcouponvalue';break;
			case 'type': $sort_by = 'fcoupontype';break;
			case 'start_date': $sort_by = 'fcouponstartdate';break;
			case 'end_date': $sort_by = 'fcouponenddate';break;
			case 'status': $sort_by = 'fcouponstatus';break;
			default: $sort_by = 'fcouponid';break;
		}
		$sort = ($this->input->get_post('sort',TRUE)) ? $this->input->get_post('sort',TRUE) : $this->order;
		$curStatus = $this->input->get_post('status',true);
		
		$this->db->join('tusers','tusers.fuserid = tcoupon.fuserid','left');
		
		$this->db->select('*, if(tcoupon.fuserid != 0, "Referral", "All User") as fusercoupon');
		
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fcouponcode like '.$this->db->escape('%'.$keyword.'%').' OR fcouponvalue like '.$this->db->escape('%'.$keyword.'%').' OR fcoupontype like '.$this->db->escape('%'.$keyword.'%').' OR fuserfirstname like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		$this->db->order_by($sort_by,$sort);
			  
		if($offset!==FALSE)
			$query = $this->db->get('tcoupon', $this->limit, $offset);	
		else	
			$query = $this->db->get('tcoupon');
		
		if ($query->num_rows() > 0){
			return $query->result_array();
		}
	}
	
	public function get_coupons_count(){	
		$this->db->select('*, if(tcoupon.fuserid != 0, "Referral", "All User") as fusercoupon');
		$this->db->join('tusers','tusers.fuserid = tcoupon.fuserid','left');
		if(!empty($this->input->get_post('s',TRUE))){
			$keyword = $this->input->get_post('s',TRUE);
			$searchwhere = 'fcouponcode like '.$this->db->escape('%'.$keyword.'%').' OR fcouponvalue like '.$this->db->escape('%'.$keyword.'%').' OR fcoupontype like '.$this->db->escape('%'.$keyword.'%').' OR fuserfirstname like '.$this->db->escape('%'.$keyword.'%');
			$this->db->where($searchwhere);	
		}
		
		$query = $this->db->get('tcoupon');
		return $query->num_rows();
	}
	
	public function get_coupon_where($where,$single=true){
		
		$this->db->select('*, if(tcoupon.fuserid != 0, "Referral", "All User") as fusercoupon');
		
		$this->db->join('tusers','tusers.fuserid = tcoupon.fuserid','left');
		$this->db->where($where);	
			  
		$query = $this->db->get('tcoupon');
		
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function get_role($single=false){
		$this->db->select('*');
		$this->db->order_by('froleid','ASC');
		$this->db->where('frolestatus',1);
		$query = $this->db->get('trole');
		
		if ($query->num_rows() > 0){
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
	
	public function user_dashboard($where,$field='count(fuserid) as totaluser'){
		$this->db->select($field);	  
		$this->db->where($where);
		$query = $this->db->get('tusers');
		//echo $this->db->last_query();
		if ($query->num_rows() > 0){
			return $query->row_array();	
		}
	}

	public function get_userid($where,$single=true){
		$this->db->select('*');
		$this->db->where('fuseremail',$where);
		$query = $this->db->get('tusers');
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}	
	}


	public function get_user_vehicle($where,$single=true){
		$this->db->select('*');
		$this->db->join('tvehicle', 'tvehicle.fvehicleid = tuservehicle.fvehicleid');
		$this->db->join('tbrand', 'tbrand.fbrandid = tvehicle.fbrandid');
		$this->db->where($where);				
		
		$query = $this->db->get('tuservehicle');
		
		if ($query->num_rows() > 0){			
			if($single)
				return $query->row_array();
			else
				return $query->result_array();
		}
	}
}
?>