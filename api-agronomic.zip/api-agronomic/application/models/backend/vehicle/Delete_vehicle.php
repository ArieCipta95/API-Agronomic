<?php class Delete_vehicle extends CI_Model {

	 public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
   
	public function deleteVehicle($vehicle){
		$this->db->where($vehicle);
		$this->db->delete('tvehicle'); 
	}
   
	public function deleteVehicleMeta($meta){
		$this->db->where($meta);
		$this->db->delete('tvehiclemeta'); 
	}

	public function deleteUserVehicle($where){
		$this->db->where('fuserid',$where);
		$this->db->delete('tuservehicle');
	}
   
}
?>