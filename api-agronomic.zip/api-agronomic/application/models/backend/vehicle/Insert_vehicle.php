<?php class Insert_vehicle extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
  public function addNewVehicle($vehicle){
	  $this->db->set($vehicle);
	  $this->db->insert('tvehicle');
	  return $this->db->insert_id();
  }

  public function addVehicleMeta($insert){
	  $this->db->set($insert);
	  $this->db->insert('tvehiclemeta');
	  return $this->db->insert_id();
  }
  
}
?>