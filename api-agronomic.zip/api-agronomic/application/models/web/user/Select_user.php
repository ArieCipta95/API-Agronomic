<?php class Select_user extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
  
	public function checkToken($user){
		$this->db->from('tusers');  
		$this->db->where('fuserid',$user['userID']);
		$this->db->where('fusergmttoken',$user['gmtToken']);
		return $this->db->count_all_results();
	}
	
	public function checkEmail($user){
		$this->db->from('tusers');  
		$this->db->where('fuseremail',$user['fuseremail']);
		return $this->db->count_all_results();
	}
	
	public function checkUsername($user){
		$this->db->from('tusers');  
		$this->db->where('fusername',$user['username']);
		return $this->db->count_all_results();
	}
	
	public function checkPass($user){
		$this->db->from('tusers');  
		$this->db->where('fuserid',$user['userID']);
		$this->db->where('fuserpassword',$user['currentPassword']);
		return $this->db->count_all_results();
	}
	
	public function checkLogin($user,$offset = FALSE){
		$this->limit = 1;
		$this->db->select('fuserid');
		$this->db->where('fuseremail',$user['fuseremail']);
		$this->db->where('fuserpassword',$user['fuserpassword']);
		$query = $this->db->get('tusers', $this->limit, $offset);
		if ($query->num_rows() > 0){
			$data = $query->row_array();
			return $data['fuserid'];
		}
	}
	
	public function checkLoginSocmed($user,$offset = FALSE){
		$sql = "SELECT * FROM `tusersmeta` m1, `tusersmeta` m2, `tusersmeta` m3
			WHERE m1.fuserid = m2.fuserid
			and m1.fuserid = m3.fuserid
			and m1.fmetakey = 'socmed_type'
			and m1.fmetavalue = ".$this->db->escape($user['socmed_type'])."
			and m2.fmetakey = 'socmed_id'
			and m2.fmetavalue = ".$this->db->escape($user['socmed_id'])."
			LIMIT 1";
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0){
			$data = $query->row_array();
			return $data['fuserid'];
		}
	}
	
	public function get_where($where,$field='*'){
		$this->db->select($field);	  
		$this->db->where($where);
		$query = $this->db->get('tusers');
		if ($query->num_rows() > 0){
			return $query->row_array();
		}
	}
  
	public function get_count_meta($meta,$offset = FALSE){
		$this->db->from('tusersmeta');  
		$this->db->where($meta);	
		return $this->db->count_all_results();
	}
}
?>