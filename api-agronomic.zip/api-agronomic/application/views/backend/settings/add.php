<h1 class="page-header"><?=$title?></h1>

<?php if(!empty($main['top'])){ ?>
<?=$main['top']?>
<?php } ?>

<?php if(!empty($main['section_title'])){ ?>
<?=$main['section_title']?>
<?php } ?>

<?php if(!empty($main['detail'])){ ?>
<?=$main['detail']?>
<?php } ?>